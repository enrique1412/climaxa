-- CLIMAXA. Ejecutar una vez en el SQL Editor de un proyecto Supabase vacío.
begin;
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null check (length(name) between 1 and 150),
  email text not null,
  role text not null default 'consulta' check (role in ('admin','comercial','consulta')),
  active boolean not null default false,
  created_at timestamptz not null default now()
);
create function public.register_profile() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles(id,name,email) values(new.id,coalesce(nullif(left(new.raw_user_meta_data->>'name',150),''),split_part(new.email,'@',1)),new.email);
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.register_profile();

create function public.current_role() returns text language sql stable security definer set search_path = '' as $$
  select role from public.profiles where id=auth.uid() and active=true;
$$;
create table public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null check(length(trim(name)) between 1 and 150),
  company text not null default '' check(length(company)<=150),
  phone text not null check(phone ~ '^[+0-9 ()-]{7,25}$'),
  email text not null default '' check(length(email)<=200),
  address text not null default '' check(length(address)<=500),
  created_at timestamptz not null default now()
);
create table public.quotes (
  id uuid primary key default gen_random_uuid(),
  number bigint generated always as identity (start with 1001) unique,
  client_id uuid not null references public.clients(id),
  title text not null check(length(trim(title)) between 1 and 200),
  service text not null check(service in ('Aire acondicionado','Paneles solares','Mantenimiento','Instalación')),
  status text not null default 'Nueva solicitud' check(status in ('Nueva solicitud','En revisión','En elaboración','Cotización enviada','Aceptada','Rechazada','Finalizada')),
  priority text not null default 'Media' check(priority in ('Baja','Media','Alta')),
  source text not null default 'WhatsApp' check(source in ('WhatsApp','Sitio web','Teléfono','Correo','Presencial')),
  description text not null default '' check(length(description)<=5000),
  items jsonb not null default '[]'::jsonb check(jsonb_typeof(items)='array'),
  tax numeric(5,2) not null default 16 check(tax>=0 and tax<=100),
  follow_up date,
  valid_until date,
  version integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index quotes_client_idx on public.quotes(client_id);
create index quotes_follow_up_idx on public.quotes(follow_up) where status in ('Nueva solicitud','En revisión','En elaboración','Cotización enviada');
create table public.events (
  id uuid primary key default gen_random_uuid(),
  quote_id uuid not null references public.quotes(id),
  kind text not null check(kind in ('created','updated','note')),
  message text not null,
  actor_id uuid references public.profiles(id) on delete set null,
  actor_name text not null,
  snapshot jsonb,
  created_at timestamptz not null default now()
);
create index events_quote_idx on public.events(quote_id,created_at);

create function public.validate_quote() returns trigger language plpgsql set search_path = '' as $$
declare item jsonb;
begin
  if jsonb_typeof(new.items)<>'array' or jsonb_array_length(new.items)>100 then raise exception 'La cotización admite hasta 100 conceptos'; end if;
  for item in select * from jsonb_array_elements(new.items) loop
    if jsonb_typeof(item)<>'object'
       or jsonb_typeof(item->'description') is distinct from 'string'
       or length(trim(item->>'description')) not between 1 and 300
       or jsonb_typeof(item->'quantity') is distinct from 'number'
       or jsonb_typeof(item->'price') is distinct from 'number' then raise exception 'Concepto inválido'; end if;
    if (item->>'quantity')::numeric<=0 or (item->>'quantity')::numeric>100000
       or (item->>'price')::numeric<0 or (item->>'price')::numeric>10000000 then raise exception 'Cantidad o precio fuera de rango'; end if;
  end loop;
  if new.status in ('Cotización enviada','Aceptada','Finalizada') and jsonb_array_length(new.items)=0 then raise exception 'Agrega conceptos antes de enviar o completar la cotización'; end if;
  if TG_OP='UPDATE' then
    new.id=old.id; new.number=old.number; new.created_at=old.created_at; new.version=old.version+1;
  else
    new.version=1; new.created_at=now();
  end if;
  new.updated_at=now();
  return new;
end; $$;
create trigger validate_quote before insert or update on public.quotes for each row execute function public.validate_quote();
create function public.audit_quote() returns trigger language plpgsql security definer set search_path = '' as $$
declare actor text; customer jsonb;
begin
  select name into actor from public.profiles where id=auth.uid();
  select to_jsonb(c) into customer from public.clients c where id=new.client_id;
  insert into public.events(quote_id,kind,message,actor_id,actor_name,snapshot)
  values(new.id,case when TG_OP='INSERT' then 'created' else 'updated' end,
    case when TG_OP='INSERT' then 'Solicitud registrada' else 'Cotización actualizada' end,
    auth.uid(),coalesce(actor,'Sistema'),to_jsonb(new)||jsonb_build_object('client_snapshot',customer));
  return new;
end; $$;
create trigger audit_quote after insert or update on public.quotes for each row execute function public.audit_quote();

alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.quotes enable row level security;
alter table public.events enable row level security;
create policy profiles_read on public.profiles for select to authenticated using(id=auth.uid() or public.current_role()='admin');
create policy clients_read on public.clients for select to authenticated using(public.current_role() is not null);
create policy clients_insert on public.clients for insert to authenticated with check(public.current_role() in ('admin','comercial'));
create policy clients_update on public.clients for update to authenticated using(public.current_role() in ('admin','comercial')) with check(public.current_role() in ('admin','comercial'));
create policy quotes_read on public.quotes for select to authenticated using(public.current_role() is not null);
create policy quotes_insert on public.quotes for insert to authenticated with check(public.current_role() in ('admin','comercial'));
create policy quotes_update on public.quotes for update to authenticated using(public.current_role() in ('admin','comercial')) with check(public.current_role() in ('admin','comercial'));
create policy events_read on public.events for select to authenticated using(public.current_role() is not null);
-- La aplicación no elimina registros históricos. Solo los triggers y RPC crean eventos.
revoke all on public.profiles,public.clients,public.quotes,public.events from anon,authenticated;
grant select on public.profiles,public.clients,public.quotes,public.events to authenticated;
grant insert(name,company,phone,email,address),update(name,company,phone,email,address) on public.clients to authenticated;
grant insert(client_id,title,service,status,priority,source,description,items,tax,follow_up,valid_until),update(client_id,title,service,status,priority,source,description,items,tax,follow_up,valid_until) on public.quotes to authenticated;
grant usage on sequence public.quotes_number_seq to authenticated;

create function public.add_note(target_quote uuid,note text) returns void language plpgsql security definer set search_path = '' as $$
declare actor text;
begin
  if coalesce(public.current_role(),'') not in ('admin','comercial') then raise exception 'Sin permiso para registrar notas'; end if;
  if note is null or length(trim(note)) not between 1 and 2000 then raise exception 'La nota debe tener entre 1 y 2000 caracteres'; end if;
  select name into actor from public.profiles where id=auth.uid();
  insert into public.events(quote_id,kind,message,actor_id,actor_name) values(target_quote,'note',trim(note),auth.uid(),actor);
end; $$;
create function public.set_user_access(target_user uuid,new_role text,is_active boolean) returns void language plpgsql security definer set search_path = '' as $$
begin
  -- Serializa cambios de acceso para evitar perder al último administrador activo.
  perform pg_advisory_xact_lock(1711042);
  if public.current_role() is distinct from 'admin' then raise exception 'Solo un administrador puede gestionar accesos'; end if;
  if target_user=auth.uid() then raise exception 'No puedes modificar tu propio acceso'; end if;
  if new_role is null or new_role not in ('admin','comercial','consulta') or is_active is null then raise exception 'Perfil inválido'; end if;
  update public.profiles set role=new_role,active=is_active where id=target_user;
  if not found then raise exception 'Usuario no encontrado'; end if;
end; $$;
revoke all on function public.current_role(),public.register_profile(),public.validate_quote(),public.audit_quote(),public.add_note(uuid,text),public.set_user_access(uuid,text,boolean) from public,anon,authenticated;
grant execute on function public.current_role(),public.add_note(uuid,text),public.set_user_access(uuid,text,boolean) to authenticated;
commit;
