-- Ejecutar DESPUÉS de schema.sql. Añade el portal público sin abrir los datos internos.
begin;
alter table public.profiles drop constraint profiles_role_check;
alter table public.profiles add constraint profiles_role_check check(role in ('admin','comercial','consulta','cliente'));
create table public.customer_accounts (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  client_id uuid not null unique references public.clients(id),
  consent_at timestamptz not null default now(),
  consent_version text not null default 'account-v1'
);
create table public.request_receipts (
  request_key uuid primary key,
  quote_id uuid not null unique references public.quotes(id),
  original_client_id uuid not null references public.clients(id),
  email text not null,
  claim_hash text not null,
  claimed_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create index request_receipts_email_date on public.request_receipts(email,created_at);
alter table public.customer_accounts enable row level security;
alter table public.request_receipts enable row level security;
revoke all on public.customer_accounts,public.request_receipts from public,anon,authenticated;
-- Estas tablas solo se utilizan a través de las funciones acotadas de abajo.

create or replace function public.register_profile() returns trigger language plpgsql security definer set search_path='' as $$
declare customer_id uuid;
begin
  if new.raw_user_meta_data->>'signup_kind'='customer' then
    if new.raw_user_meta_data->>'account_consent' is distinct from 'true' then raise exception 'Se requiere consentimiento para crear la cuenta'; end if;
    insert into public.profiles(id,name,email,role,active) values(new.id,trim(left(new.raw_user_meta_data->>'name',150)),new.email,'cliente',true);
    insert into public.clients(name,phone,email,company,address) values(trim(left(new.raw_user_meta_data->>'name',150)),new.raw_user_meta_data->>'phone',new.email,coalesce(left(new.raw_user_meta_data->>'company',150),''),coalesce(left(new.raw_user_meta_data->>'address',500),'')) returning id into customer_id;
    insert into public.customer_accounts(user_id,client_id) values(new.id,customer_id);
  else
    insert into public.profiles(id,name,email) values(new.id,coalesce(nullif(left(new.raw_user_meta_data->>'name',150),''),split_part(new.email,'@',1)),new.email);
  end if;
  return new;
end; $$;
-- Nunca confiar en role/active proporcionados como metadatos del registro.
drop policy clients_read on public.clients;
drop policy quotes_read on public.quotes;
drop policy events_read on public.events;
create policy clients_read on public.clients for select to authenticated using(public.current_role() in ('admin','comercial','consulta'));
create policy quotes_read on public.quotes for select to authenticated using(public.current_role() in ('admin','comercial','consulta'));
create policy events_read on public.events for select to authenticated using(public.current_role() in ('admin','comercial','consulta'));

create function public.submit_guest_request(payload jsonb,submission_key uuid,claim_token text) returns jsonb language plpgsql security definer set search_path='' as $$
declare receipt public.request_receipts; customer_id uuid; q public.quotes; normalized_email text;
begin
  if payload->>'contact_consent' is distinct from 'true' then raise exception 'Autoriza que te contactemos para atender la solicitud'; end if;
  if claim_token is null or claim_token !~ '^[a-f0-9]{64}$' or submission_key is null then raise exception 'Identificador inválido'; end if;
  normalized_email=lower(trim(payload->>'email'));
  if normalized_email is null or length(normalized_email)>200 or normalized_email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' then raise exception 'Correo inválido'; end if;
  -- Un mismo envío es idempotente, incluso si se reintenta tras perder conexión.
  perform pg_advisory_xact_lock(hashtextextended(submission_key::text,0));
  select * into receipt from public.request_receipts where request_key=submission_key;
  if found then
    if receipt.claim_hash<>encode(sha256(convert_to(claim_token,'UTF8')),'hex') then raise exception 'Identificador inválido'; end if;
    select * into q from public.quotes where id=receipt.quote_id;
    return jsonb_build_object('number',q.number);
  end if;
  perform pg_advisory_xact_lock(hashtextextended(normalized_email,1));
  if (select count(*) from public.request_receipts where email=normalized_email and created_at>now()-interval '1 hour')>=5 then raise exception 'Has enviado varias solicitudes. Intenta más tarde o contáctanos por WhatsApp'; end if;
  insert into public.clients(name,phone,email,company,address) values(trim(payload->>'name'),payload->>'phone',normalized_email,coalesce(payload->>'company',''),coalesce(payload->>'address','')) returning id into customer_id;
  insert into public.quotes(client_id,title,service,description,source) values(customer_id,trim(payload->>'title'),payload->>'service',coalesce(payload->>'description',''),'Sitio web') returning * into q;
  insert into public.request_receipts(request_key,quote_id,original_client_id,email,claim_hash) values(submission_key,q.id,customer_id,normalized_email,encode(sha256(convert_to(claim_token,'UTF8')),'hex'));
  return jsonb_build_object('number',q.number);
end; $$;

create function public.claim_guest_request(submission_key uuid,claim_token text) returns void language plpgsql security definer set search_path='' as $$
declare customer_id uuid; verified_email text; receipt public.request_receipts;
begin
  if public.current_role() is distinct from 'cliente' then raise exception 'Inicia sesión con tu cuenta de cliente'; end if;
  select lower(email) into verified_email from auth.users where id=auth.uid() and email_confirmed_at is not null;
  if verified_email is null then raise exception 'Confirma tu correo antes de vincular la solicitud'; end if;
  select * into receipt from public.request_receipts where request_key=submission_key for update;
  if not found or receipt.email<>verified_email or claim_token is null or receipt.claim_hash<>encode(sha256(convert_to(claim_token,'UTF8')),'hex') or receipt.created_at<now()-interval '30 days' then raise exception 'No se pudo vincular esta solicitud'; end if;
  if receipt.claimed_by=auth.uid() then return; end if;
  if receipt.claimed_by is not null then raise exception 'La solicitud ya está vinculada'; end if;
  select client_id into customer_id from public.customer_accounts where user_id=auth.uid();
  if customer_id is null then raise exception 'Cuenta no disponible'; end if;
  update public.quotes set client_id=customer_id where id=receipt.quote_id and client_id=receipt.original_client_id;
  if not found then raise exception 'La solicitud cambió de cliente. Contacta a CLIMAXA para revisarla'; end if;
  update public.request_receipts set claimed_by=auth.uid() where request_key=submission_key;
end; $$;

create function public.my_customer_account() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare result jsonb;
begin
  if public.current_role() is distinct from 'cliente' then raise exception 'Inicia sesión con tu cuenta de cliente'; end if;
  select jsonb_build_object('name',c.name,'email',c.email,'phone',c.phone,'company',c.company,'address',c.address,'consent_at',a.consent_at) into result
  from public.customer_accounts a join public.clients c on c.id=a.client_id where a.user_id=auth.uid();
  return result;
end; $$;
create function public.my_customer_quotes() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare result jsonb;
begin
  if public.current_role() is distinct from 'cliente' then raise exception 'Inicia sesión con tu cuenta de cliente'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',q.id,'number',q.number,'title',q.title,'service',q.service,'status',q.status,'created_at',q.created_at,'updated_at',q.updated_at,'version',q.version,
    'items',case when q.status in ('Cotización enviada','Aceptada','Rechazada','Finalizada') then q.items else '[]'::jsonb end,
    'tax',case when q.status in ('Cotización enviada','Aceptada','Rechazada','Finalizada') then q.tax else null end,
    'valid_until',case when q.status in ('Cotización enviada','Aceptada','Rechazada','Finalizada') then q.valid_until else null end
  ) order by q.created_at desc),'[]'::jsonb) into result
  from public.quotes q join public.customer_accounts a on a.client_id=q.client_id where a.user_id=auth.uid();
  return result;
end; $$;
create function public.submit_customer_request(payload jsonb,submission_key uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare customer_id uuid; q public.quotes; previous public.request_receipts; customer_email text;
begin
  if public.current_role() is distinct from 'cliente' then raise exception 'Inicia sesión con tu cuenta de cliente'; end if;
  if submission_key is null then raise exception 'Identificador inválido'; end if;
  select a.client_id,c.email into customer_id,customer_email from public.customer_accounts a join public.clients c on c.id=a.client_id where user_id=auth.uid();
  if customer_id is null then raise exception 'Cuenta no disponible'; end if;
  perform pg_advisory_xact_lock(hashtextextended(submission_key::text,0));
  select * into previous from public.request_receipts where request_key=submission_key;
  if found then
    if previous.claimed_by is distinct from auth.uid() then raise exception 'Identificador inválido'; end if;
    select * into q from public.quotes where id=previous.quote_id;
    return jsonb_build_object('number',q.number);
  end if;
  perform pg_advisory_xact_lock(hashtextextended(customer_email,1));
  if (select count(*) from public.request_receipts where email=customer_email and created_at>now()-interval '1 hour')>=5 then raise exception 'Has enviado varias solicitudes. Intenta más tarde'; end if;
  insert into public.quotes(client_id,title,service,description,source) values(customer_id,trim(payload->>'title'),payload->>'service',coalesce(payload->>'description',''),'Sitio web') returning * into q;
  insert into public.request_receipts(request_key,quote_id,original_client_id,email,claim_hash,claimed_by) values(submission_key,q.id,customer_id,customer_email,'',auth.uid());
  return jsonb_build_object('number',q.number);
end; $$;
-- Mantener los clientes en su perfil: el equipo puede activar/desactivar, no ascenderlos.
create or replace function public.set_user_access(target_user uuid,new_role text,is_active boolean) returns void language plpgsql security definer set search_path='' as $$
declare old_role text;
begin
  perform pg_advisory_xact_lock(1711042);
  if public.current_role() is distinct from 'admin' then raise exception 'Solo un administrador puede gestionar accesos'; end if;
  if target_user=auth.uid() then raise exception 'No puedes modificar tu propio acceso'; end if;
  select role into old_role from public.profiles where id=target_user;
  if not found then raise exception 'Usuario no encontrado'; end if;
  if new_role is null or is_active is null or (old_role='cliente' and new_role<>'cliente') or (old_role<>'cliente' and new_role not in ('admin','comercial','consulta')) then raise exception 'Perfil inválido'; end if;
  update public.profiles set role=new_role,active=is_active where id=target_user;
end; $$;
revoke all on function public.submit_guest_request(jsonb,uuid,text),public.claim_guest_request(uuid,text),public.my_customer_account(),public.my_customer_quotes(),public.submit_customer_request(jsonb,uuid) from public,anon,authenticated;
grant execute on function public.submit_guest_request(jsonb,uuid,text) to anon,authenticated;
grant execute on function public.claim_guest_request(uuid,text),public.my_customer_account(),public.my_customer_quotes(),public.submit_customer_request(jsonb,uuid) to authenticated;
commit;
