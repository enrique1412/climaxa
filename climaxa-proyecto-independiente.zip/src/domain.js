export const STATUSES = [
  "Nueva solicitud",
  "En revisión",
  "En elaboración",
  "Cotización enviada",
  "Aceptada",
  "Rechazada",
  "Finalizada",
];
export const SERVICES = [
  "Aire acondicionado",
  "Paneles solares",
  "Mantenimiento",
  "Instalación",
];
export const CLOSED = ["Aceptada", "Rechazada", "Finalizada"];
export const money = (n) =>
  new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency: "MXN",
    maximumFractionDigits: 2,
  }).format(n);
export const date = (value) =>
  value
    ? new Intl.DateTimeFormat("es-MX", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }).format(new Date(value.length === 10 ? `${value}T12:00:00` : value))
    : "Sin fecha";
export const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
export const escapeHtml = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
export function totals(items, tax = 16) {
  const subtotalCents = items.reduce(
    (sum, item) =>
      sum + Math.round(Number(item.quantity) * Number(item.price) * 100),
    0,
  );
  const taxCents = Math.round((subtotalCents * Number(tax)) / 100);
  return {
    subtotal: subtotalCents / 100,
    tax: taxCents / 100,
    total: (subtotalCents + taxCents) / 100,
  };
}
export function validateQuote(q) {
  if (
    !q.client_id ||
    !q.title?.trim() ||
    !q.service ||
    !STATUSES.includes(q.status)
  )
    throw new Error("Completa el cliente, el asunto, el servicio y el estado.");
  if (
    !Number.isFinite(Number(q.tax)) ||
    Number(q.tax) < 0 ||
    Number(q.tax) > 100
  )
    throw new Error("El IVA debe estar entre 0 y 100.");
  if (
    !Array.isArray(q.items) ||
    q.items.length > 100 ||
    q.items.some(
      (i) =>
        !i.description?.trim() ||
        !Number.isFinite(Number(i.quantity)) ||
        !Number.isFinite(Number(i.price)) ||
        Number(i.quantity) <= 0 ||
        Number(i.quantity) > 100000 ||
        Number(i.price) < 0 ||
        Number(i.price) > 10000000,
    )
  )
    throw new Error("Revisa los conceptos, cantidades y precios.");
  if (
    ["Cotización enviada", "Aceptada", "Finalizada"].includes(q.status) &&
    !q.items.length
  )
    throw new Error(
      "Agrega al menos un concepto antes de enviar o completar la cotización.",
    );
  return q;
}
export function csvCell(value) {
  let text = String(value ?? "");
  if (/^[\s]*[=+\-@]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}
export function pending(quotes) {
  return quotes.filter((q) => !CLOSED.includes(q.status));
}
