import { createClient } from "@supabase/supabase-js";
import { seed } from "./seed.js";
import { validateQuote } from "./domain.js";
export const demo = import.meta.env.VITE_DEMO_MODE === "true";
const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
export const configured = Boolean(url && key);
export const supabase = !demo && configured ? createClient(url, key) : null;
const KEY = "climaxa-demo-v1";
let state;
function local() {
  {
    try {
      state = JSON.parse(localStorage.getItem(KEY));
    } catch {
      /* Reset corrupt demo data. */
    }
  }
  if (!state?.quotes || !state?.clients || !state?.profile) state = seed();
  return state;
}
function persist(next) {
  localStorage.setItem(KEY, JSON.stringify(next));
  state = next;
}
function checked(result) {
  if (result.error) throw new Error(result.error.message);
  return result.data;
}
export async function session() {
  if (demo) return local().profile;
  if (!supabase) return null;
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  if (!data.session) return null;
  const profile = checked(
    await supabase
      .from("profiles")
      .select("*")
      .eq("id", data.session.user.id)
      .single(),
  );
  if (!profile.active)
    throw new Error(
      "Tu cuenta está pendiente de activación. Contacta al administrador.",
    );
  return profile;
}
export async function signIn(email, password) {
  checked(await supabase.auth.signInWithPassword({ email, password }));
}
export async function signOut() {
  if (supabase) checked(await supabase.auth.signOut());
}
// Fetch all records in bounded pages; Supabase caps a single response at 1,000 rows.
async function all(table, order = "id") {
  const result = [];
  for (let from = 0; ; from += 500) {
    const page = checked(
      await supabase
        .from(table)
        .select("*")
        .order(order)
        .range(from, from + 499),
    );
    result.push(...page);
    if (page.length < 500) return result;
  }
}
export async function load() {
  if (demo) return structuredClone(local());
  const [clients, quotes, profiles, events] = await Promise.all([
    all("clients"),
    all("quotes"),
    all("profiles"),
    all("events"),
  ]);
  return { clients, quotes, profiles, events };
}
export async function saveClient(input, id) {
  if (!input.name.trim() || !input.phone.trim())
    throw new Error("El nombre y teléfono son obligatorios.");
  if (demo) {
    const next = structuredClone(local());
    if (id)
      Object.assign(
        next.clients.find((c) => c.id === id),
        input,
      );
    else
      next.clients.push({
        ...input,
        id: crypto.randomUUID(),
        created_at: new Date().toISOString(),
      });
    persist(next);
    return;
  }
  checked(
    id
      ? await supabase.from("clients").update(input).eq("id", id)
      : await supabase.from("clients").insert(input),
  );
}
export async function saveQuote(input, id, version) {
  validateQuote(input);
  if (demo) {
    const next = structuredClone(local());
    let q = next.quotes.find((q) => q.id === id);
    if (q && q.version !== version)
      throw new Error(
        "Esta cotización cambió. Actualiza la página e inténtalo de nuevo.",
      );
    if (!q) {
      q = {
        id: crypto.randomUUID(),
        number: Math.max(1000, ...next.quotes.map((q) => q.number)) + 1,
        created_at: new Date().toISOString(),
        version: 0,
      };
      next.quotes.unshift(q);
    }
    Object.assign(q, input, {
      version: q.version + 1,
      updated_at: new Date().toISOString(),
    });
    next.events.unshift({
      id: crypto.randomUUID(),
      quote_id: q.id,
      kind: id ? "updated" : "created",
      message: id ? "Cotización actualizada" : "Solicitud registrada",
      actor_name: next.profile.name,
      created_at: q.updated_at,
      snapshot: {
        ...structuredClone(q),
        client_snapshot: structuredClone(
          next.clients.find((c) => c.id === q.client_id),
        ),
      },
    });
    persist(next);
    return q.id;
  }
  const result = checked(
    id
      ? await supabase
          .from("quotes")
          .update(input)
          .eq("id", id)
          .eq("version", version)
          .select("id")
      : await supabase.from("quotes").insert(input).select("id"),
  );
  if (!result.length)
    throw new Error(
      "La cotización cambió o no tienes permiso. Actualiza la página antes de guardar.",
    );
  return result[0].id;
}
export async function addNote(quote_id, message) {
  if (!message.trim()) throw new Error("Escribe una nota.");
  if (demo) {
    const next = structuredClone(local());
    next.events.unshift({
      id: crypto.randomUUID(),
      quote_id,
      kind: "note",
      message,
      actor_name: next.profile.name,
      created_at: new Date().toISOString(),
    });
    persist(next);
    return;
  }
  checked(
    await supabase.rpc("add_note", { target_quote: quote_id, note: message }),
  );
}
export async function updateUser(id, role, active) {
  if (demo)
    throw new Error(
      "La administración de usuarios estará disponible al conectar Supabase.",
    );
  checked(
    await supabase.rpc("set_user_access", {
      target_user: id,
      new_role: role,
      is_active: active,
    }),
  );
}

// Solo para compartir el estado ficticio entre las dos vistas de la demostración.
export function readDemo() {
  return structuredClone(local());
}
export function writeDemo(value) {
  persist(value);
}
