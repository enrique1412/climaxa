import {
  demo,
  supabase,
  configured,
  readDemo,
  writeDemo,
  session,
  signIn,
} from "./data.js";
import { validateQuote } from "./domain.js";
export { demo, configured };
const DEMO_SESSION = "climaxa-customer-demo";
const PENDING = "climaxa-pending-claim";
const check = (result) => {
  if (result.error) throw new Error(result.error.message);
  return result.data;
};
export const receiptToken = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(32)), (n) =>
    n.toString(16).padStart(2, "0"),
  ).join("");
export function pendingClaim() {
  try {
    return JSON.parse(sessionStorage.getItem(PENDING)) || null;
  } catch {
    return null;
  }
}
export function rememberClaim(receipt) {
  sessionStorage.setItem(PENDING, JSON.stringify(receipt));
}
export function publicQuote(q) {
  const sent = [
    "Cotización enviada",
    "Aceptada",
    "Rechazada",
    "Finalizada",
  ].includes(q.status);
  return Object.fromEntries(
    [
      "id",
      "number",
      "title",
      "service",
      "status",
      "created_at",
      "updated_at",
      "version",
    ]
      .map((k) => [k, q[k]])
      .concat([
        ["items", sent ? q.items : []],
        ["tax", sent ? q.tax : null],
        ["valid_until", sent ? q.valid_until : null],
      ]),
  );
}
function demoCustomer() {
  const id = sessionStorage.getItem(DEMO_SESSION);
  const d = readDemo();
  return (
    d.profiles.find((p) => p.id === id && p.role === "cliente" && p.active) ||
    null
  );
}
function requireBackend() {
  if (!demo && !supabase)
    throw new Error(
      "El formulario aún no está conectado. Puedes solicitar tu cotización por WhatsApp.",
    );
}
export async function customerSession() {
  if (demo) return demoCustomer();
  return session();
}
export async function login(email, password) {
  if (demo) {
    const p = readDemo().profiles.find(
      (p) =>
        p.email.toLowerCase() === email.toLowerCase() &&
        p.role === "cliente" &&
        p.active,
    );
    if (!p)
      throw new Error("Primero crea una cuenta ficticia en esta demostración.");
    sessionStorage.setItem(DEMO_SESSION, p.id);
    return;
  }
  requireBackend();
  await signIn(email, password);
}
export async function logout() {
  if (demo) sessionStorage.removeItem(DEMO_SESSION);
  else check(await supabase.auth.signOut());
}
export async function submitRequest(payload, key, token) {
  requireBackend();
  const customer = await customerSession();
  if (customer && customer.role !== "cliente")
    throw new Error(
      "Para solicitar como cliente, cierra la sesión del equipo o utiliza otro navegador.",
    );
  if (demo) {
    const d = readDemo();
    d.receipts ??= [];
    const previous = d.receipts.find((r) => r.key === key);
    if (previous) return { number: previous.number };
    let c = d.clients.find((c) => c.owner_id === customer?.id && customer);
    if (!c) {
      if (!payload.contact_consent)
        throw new Error(
          "Autoriza que te contactemos para atender tu solicitud.",
        );
      c = {
        id: crypto.randomUUID(),
        name: payload.name,
        phone: payload.phone,
        email: payload.email.toLowerCase(),
        company: payload.company || "",
        address: payload.address || "",
        created_at: new Date().toISOString(),
      };
      d.clients.push(c);
    }
    const q = {
      id: crypto.randomUUID(),
      number: Math.max(1000, ...d.quotes.map((q) => q.number)) + 1,
      client_id: c.id,
      title: payload.title,
      service: payload.service,
      description: payload.description || "",
      source: "Sitio web",
      priority: "Media",
      status: "Nueva solicitud",
      items: [],
      tax: 16,
      follow_up: null,
      valid_until: null,
      version: 1,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    validateQuote(q);
    d.quotes.unshift(q);
    d.events.unshift({
      id: crypto.randomUUID(),
      quote_id: q.id,
      kind: "created",
      message: "Solicitud recibida desde el sitio web",
      actor_name: customer?.name || "Visitante",
      created_at: q.created_at,
      snapshot: { ...q, client_snapshot: { ...c } },
    });
    d.receipts.push({
      key,
      token,
      number: q.number,
      quote_id: q.id,
      email: c.email,
      claimed_by: customer?.id || null,
    });
    writeDemo(d);
    return { number: q.number };
  }
  return check(
    await supabase.rpc(
      customer ? "submit_customer_request" : "submit_guest_request",
      customer
        ? { payload, submission_key: key }
        : { payload, submission_key: key, claim_token: token },
    ),
  );
}
export async function registerAccount(data) {
  requireBackend();
  if (!data.account_consent)
    throw new Error("Crear una cuenta requiere tu autorización.");
  const pending = pendingClaim();
  if (demo) {
    const d = readDemo();
    if (
      d.profiles.some((p) => p.email.toLowerCase() === data.email.toLowerCase())
    )
      throw new Error("Ya existe esta cuenta de demostración. Inicia sesión.");
    const p = {
      id: crypto.randomUUID(),
      name: data.name,
      email: data.email.toLowerCase(),
      role: "cliente",
      active: true,
      consent_at: new Date().toISOString(),
    };
    d.profiles.push(p);
    d.clients.push({
      id: crypto.randomUUID(),
      owner_id: p.id,
      name: data.name,
      email: p.email,
      phone: data.phone,
      company: data.company || "",
      address: data.address || "",
      created_at: p.consent_at,
    });
    writeDemo(d);
    sessionStorage.setItem(DEMO_SESSION, p.id);
    return { confirmed: true };
  }
  const result = check(
    await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: {
        emailRedirectTo: `${location.origin}/#cuenta`,
        data: {
          signup_kind: "customer",
          account_consent: true,
          name: data.name,
          phone: data.phone,
          company: data.company || "",
          address: data.address || "",
          pending_claim_key: pending?.key || null,
          pending_claim_token: pending?.token || null,
        },
      },
    }),
  );
  return { confirmed: Boolean(result.session) };
}
export async function claimRequest() {
  if (demo) {
    const p = demoCustomer(),
      pending = pendingClaim();
    if (!p || !pending) return;
    const d = readDemo(),
      r = d.receipts?.find(
        (r) => r.key === pending.key && r.token === pending.token,
      );
    if (!r || r.email !== p.email)
      throw new Error(
        "La solicitud sigue registrada como invitado. Inicia sesión con el mismo correo para vincularla.",
      );
    if (r.claimed_by && r.claimed_by !== p.id)
      throw new Error("La solicitud ya está vinculada.");
    if (!r.claimed_by) {
      const q = d.quotes.find((q) => q.id === r.quote_id);
      q.client_id = d.clients.find((c) => c.owner_id === p.id).id;
      q.version++;
      q.updated_at = new Date().toISOString();
      r.claimed_by = p.id;
      writeDemo(d);
    }
    sessionStorage.removeItem(PENDING);
    return;
  }
  const auth = check(await supabase.auth.getUser());
  const metadata = auth.user?.user_metadata;
  const pending =
    pendingClaim() ||
    (metadata?.pending_claim_key
      ? { key: metadata.pending_claim_key, token: metadata.pending_claim_token }
      : null);
  if (!pending) return;
  check(
    await supabase.rpc("claim_guest_request", {
      submission_key: pending.key,
      claim_token: pending.token,
    }),
  );
  sessionStorage.removeItem(PENDING);
  if (metadata?.pending_claim_key)
    check(
      await supabase.auth.updateUser({
        data: { pending_claim_key: null, pending_claim_token: null },
      }),
    );
}
export async function accountData() {
  if (demo) {
    const p = demoCustomer();
    if (!p) throw new Error("Inicia sesión.");
    const d = readDemo(),
      c = d.clients.find((c) => c.owner_id === p.id);
    return {
      account: { ...c, consent_at: p.consent_at },
      quotes: d.quotes.filter((q) => q.client_id === c.id).map(publicQuote),
    };
  }
  const [a, q] = await Promise.all([
    supabase.rpc("my_customer_account"),
    supabase.rpc("my_customer_quotes"),
  ]);
  return { account: check(a), quotes: check(q) };
}
export async function recover(email) {
  requireBackend();
  if (demo)
    throw new Error("La demostración no utiliza contraseñas ni envía correos.");
  check(
    await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${location.origin}/?recuperar=1#cuenta`,
    }),
  );
}
export async function changePassword(password) {
  check(await supabase.auth.updateUser({ password }));
}
