import "./style.css";
import {
  createIcons,
  LayoutDashboard,
  FileText,
  Users,
  CalendarClock,
  History,
  ShieldCheck,
  Plus,
  Search,
  ArrowUpRight,
  ArrowRight,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  X,
  Snowflake,
  Sun,
  Wrench,
  Download,
  MoreHorizontal,
  Check,
  Clock3,
  CircleHelp,
  LogOut,
  Menu,
  RefreshCw,
  Phone,
  Mail,
  MapPin,
  Pencil,
  Printer,
  MessageCircle,
  Eye,
  CheckCircle2,
  Send,
  Inbox,
  AlertCircle,
} from "lucide";
import * as api from "./data.js";
import {
  STATUSES,
  SERVICES,
  money,
  date,
  today,
  totals,
  escapeHtml as h,
  pending,
  csvCell,
} from "./domain.js";
const icons = {
  LayoutDashboard,
  FileText,
  Users,
  CalendarClock,
  History,
  ShieldCheck,
  Plus,
  Search,
  ArrowUpRight,
  ArrowRight,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  X,
  Snowflake,
  Sun,
  Wrench,
  Download,
  MoreHorizontal,
  Check,
  Clock3,
  CircleHelp,
  LogOut,
  Menu,
  RefreshCw,
  Phone,
  Mail,
  MapPin,
  Pencil,
  Printer,
  MessageCircle,
  Eye,
  CheckCircle2,
  Send,
  Inbox,
  AlertCircle,
};
const icon = (name, cls = "") =>
  `<i data-lucide="${name}" class="${cls}" aria-hidden="true"></i>`;
const app = document.querySelector("#app"),
  modal = document.querySelector("#modal");
let db = { clients: [], quotes: [], profiles: [], events: [] },
  profile,
  page = "dashboard",
  query = "",
  status = "",
  service = "",
  pageNumber = 1,
  sort = "recent",
  busy = false;
let returnFocus;
const canEdit = () => ["admin", "comercial"].includes(profile?.role);
const clientFor = (q) =>
  db.clients.find((c) => c.id === q.client_id) || {
    name: "Cliente no disponible",
    company: "",
  };
const total = (q) => totals(q.items, q.tax).total;
const roleName = (r) =>
  ({
    admin: "Administrador",
    comercial: "Comercial",
    consulta: "Solo consulta",
    cliente: "Cliente",
  })[r] || r;
const initials = (name) =>
  name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0])
    .join("")
    .toUpperCase();
const badge = (s) =>
  `<span class="badge state-${STATUSES.indexOf(s)}"><span></span>${h(s)}</span>`;
const serviceIcon = (s) =>
  s === "Paneles solares"
    ? "sun"
    : s === "Mantenimiento"
      ? "wrench"
      : "snowflake";
const ref = (q) => `COT-${String(q.number).padStart(4, "0")}`;
const pendingList = () =>
  pending(db.quotes).sort((a, b) =>
    (a.follow_up || "9999").localeCompare(b.follow_up || "9999"),
  );
const dueList = () =>
  pendingList().filter((q) => q.follow_up && q.follow_up <= today());
function paintIcons() {
  createIcons({ icons, attrs: { "stroke-width": 1.7 } });
}
function toast(message, error = false) {
  const el = document.querySelector("#toast");
  el.textContent = message;
  el.className = `visible ${error ? "error" : ""}`;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (el.className = ""), 5000);
}
async function refresh() {
  db = await api.load();
}
function openModal(html) {
  returnFocus = document.activeElement;
  modal.innerHTML = html;
  modal.setAttribute("aria-labelledby", "dialog-title");
  modal.showModal();
  paintIcons();
}
function closeModal() {
  modal.close();
  returnFocus?.focus();
}
modal.addEventListener("click", (event) => {
  if (event.target === modal) closeModal();
});
modal.addEventListener("close", () => {
  if (!modal.open) modal.innerHTML = "";
});
function modalHeader(eyebrow, title) {
  return `<div class="modal-head"><div><span class="eyebrow">${eyebrow}</span><h2 id="dialog-title">${title}</h2></div><button class="icon-btn" data-action="close" aria-label="Cerrar">${icon("x")}</button></div>`;
}
function options(values, current, empty = "") {
  return `${empty ? `<option value="">${empty}</option>` : ""}${values.map((v) => `<option value="${h(v)}" ${v === current ? "selected" : ""}>${h(v)}</option>`).join("")}`;
}
function empty(
  title,
  detail = "Prueba con otros filtros o registra una nueva solicitud.",
) {
  return `<div class="empty">${icon("inbox")}<h3>${title}</h3><p>${detail}</p></div>`;
}
function navigation() {
  const entries = [
    ["dashboard", "layout-dashboard", "Resumen"],
    ["quotes", "file-text", "Cotizaciones"],
    ["clients", "users", "Clientes"],
    ["followup", "calendar-clock", "Seguimiento"],
    ["history", "history", "Historial"],
  ];
  if (profile.role === "admin")
    entries.push(["team", "shield-check", "Usuarios"]);
  return entries
    .map(
      ([id, i, label]) =>
        `<button data-page="${id}" class="nav-item ${page === id ? "active" : ""}" ${page === id ? 'aria-current="page"' : ""}>${icon(i)}<span>${label}</span>${id === "followup" && dueList().length ? `<span class="nav-count">${dueList().length}</span>` : ""}</button>`,
    )
    .join("");
}
function render() {
  const titles = {
    dashboard: "Resumen general",
    quotes: "Cotizaciones",
    clients: "Clientes",
    followup: "Seguimiento",
    history: "Historial de actividad",
    team: "Usuarios y permisos",
  };
  app.innerHTML = `<div class="shell"><aside class="sidebar" id="sidebar"><a class="brand" href="#" data-page="dashboard" aria-label="CLIMAXA, inicio"><img src="/logo.webp" alt="CLIMAXA"/><span>GESTIÓN COMERCIAL</span></a><span class="nav-label">ESPACIO DE TRABAJO</span><nav aria-label="Navegación principal">${navigation()}</nav><div class="sidebar-bottom"><div class="support-card">${icon("circle-help")}<strong>Todo bajo control</strong><p>De la primera consulta a un proyecto terminado.</p><button data-action="help">Conoce tu espacio ${icon("arrow-up-right")}</button></div><a href="/" target="_blank" rel="noopener noreferrer" class="website-link">Ver sitio público ${icon("arrow-up-right")}</a><div class="sidebar-sign">CLIMATIZACIÓN Y ENERGÍA SOLAR</div></div></aside><div class="main-wrap"><header class="topbar"><div class="breadcrumb"><button data-action="menu" class="icon-btn mobile-menu" aria-label="Abrir navegación">${icon("menu")}</button><span>Espacio de trabajo</span><span class="crumb-slash">/</span><strong>${titles[page]}</strong></div><div class="topbar-right"><span class="connection"><span></span>${api.demo ? "Demostración" : "Conectado"}</span><div class="top-divider"></div><div class="avatar">${h(initials(profile.name))}</div><div class="user-info"><strong>${h(profile.name)}</strong><span>${roleName(profile.role)}</span></div>${!api.demo ? `<button class="icon-btn" data-action="logout" aria-label="Cerrar sesión">${icon("log-out")}</button>` : ""}</div></header><main id="main"><div class="page-heading"><div><div class="eyebrow">TU NEGOCIO, EN UN SOLO LUGAR</div><h1>${titles[page]}<span class="heading-dot">.</span></h1><p>${{ dashboard: "Una visión clara de tus solicitudes y de lo que sigue.", quotes: "Organiza cada propuesta, desde la solicitud hasta el cierre.", clients: "Cada cliente y sus datos de contacto, siempre a mano.", followup: "El siguiente paso para cada oportunidad.", history: "La historia de tus cotizaciones, cambio a cambio.", team: "Un espacio de trabajo con el acceso adecuado para cada persona." }[page]}</p></div><div class="heading-actions">${page === "clients" && canEdit() ? `<button class="btn primary" data-action="new-client">${icon("plus")} Nuevo cliente</button>` : canEdit() && page !== "team" ? `<button class="btn primary" data-action="new-quote">${icon("plus")} Nueva cotización</button>` : ""}</div></div>${api.demo ? '<div class="demo-note"><span class="demo-dot"></span> Espacio de demostración <span>· Datos ficticios guardados solo en este navegador. No ingreses datos reales.</span></div>' : ""}${page === "dashboard" ? dashboard() : page === "quotes" ? quotesPage() : page === "clients" ? clientsPage() : page === "followup" ? followupPage() : page === "history" ? historyPage() : teamPage()}<footer><span>© ${new Date().getFullYear()} CLIMAXA <span class="footer-separator">/</span> Gestión de cotizaciones</span><span>Climatizamos espacios. Conectamos oportunidades.</span></footer></main></div></div>`;
  paintIcons();
}
function dashboard() {
  const active = pendingList(),
    sent = db.quotes.filter((q) => q.status === "Cotización enviada"),
    accepted = db.quotes.filter(
      (q) => q.status === "Aceptada" || q.status === "Finalizada",
    );
  const stats = [
    [
      "Solicitudes activas",
      active.length,
      "Por atender y dar seguimiento",
      "file-text",
      "blue",
    ],
    [
      "Cotizaciones enviadas",
      sent.length,
      "En espera de una respuesta",
      "send",
      "amber",
    ],
    [
      "Proyectos aceptados",
      accepted.length,
      "Aceptados y finalizados",
      "check-circle-2",
      "green",
    ],
    [
      "Valor de oportunidades",
      money(active.reduce((s, q) => s + total(q), 0)),
      "Importe de solicitudes activas · MXN",
      "arrow-up-right",
      "purple",
    ],
  ];
  return `<section class="stats-grid">${stats.map(([label, value, detail, i, color]) => `<article class="stat-card"><div class="stat-top"><span>${label}</span><div class="stat-icon ${color}">${icon(i)}</div></div><strong class="stat-value ${typeof value === "string" ? "currency" : ""}">${value}</strong><span class="stat-detail">${detail}</span></article>`).join("")}</section><section class="dashboard-middle"><article class="pipeline panel"><div class="section-head"><div><h2>El camino de tus cotizaciones</h2><p>Cada solicitud, un paso más cerca.</p></div><span class="subtle-pill">${db.quotes.length} en total</span></div><div class="pipeline-track">${STATUSES.map(
    (s, i) => {
      const n = db.quotes.filter((q) => q.status === s).length;
      return `<button class="pipeline-stage" data-filter-status="${h(s)}"><div class="stage-top"><span class="stage-dot state-${i}">${icon(i === 4 || i === 6 ? "check" : i === 5 ? "x" : i === 3 ? "send" : "clock-3")}</span>${i < 6 ? '<span class="stage-line"></span>' : ""}</div><strong>${n}</strong><span>${s}</span></button>`;
    },
  ).join(
    "",
  )}</div></article><article class="brand-card"><div class="brand-card-overlay"></div><div class="brand-card-body"><span class="brand-kicker">EL SIGUIENTE PASO CUENTA</span><h2>Grandes proyectos.<br/>Mejores conexiones.</h2><p>Un buen seguimiento hace la diferencia.</p><button class="btn light" data-page="followup">Ver pendientes ${icon("arrow-right")}</button></div><span class="decor-sun">${icon("sun")}</span></article></section><section class="dashboard-bottom"><article class="panel recent"><div class="section-head"><div><h2>Cotizaciones recientes</h2><p>Las últimas oportunidades de tu negocio.</p></div><button class="text-btn" data-page="quotes">Ver todas ${icon("arrow-right")}</button></div>${quoteTable([...db.quotes].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 5), true)}</article><article class="panel follow-card"><div class="section-head"><div><h2>Por dar seguimiento</h2><p>Hoy es un buen día para conectar.</p></div><span class="number-pill">${dueList().length}</span></div><div class="follow-list">${
    dueList()
      .slice(0, 3)
      .map(
        (q) =>
          `<button class="follow-item" data-open="${q.id}"><span class="service-tile ${q.service === "Paneles solares" ? "solar" : ""}">${icon(serviceIcon(q.service))}</span><span class="follow-copy"><strong>${h(clientFor(q).name)}</strong><span>${h(q.title)}</span><small class="${q.follow_up < today() ? "overdue" : ""}">${icon("clock-3")}${q.follow_up < today() ? "Vencida · " : ""}${date(q.follow_up)}</small></span>${icon("chevron-right")}</button>`,
      )
      .join("") ||
    empty("¡Todo al día!", "No tienes seguimientos vencidos para hoy.")
  }</div><button class="follow-footer" data-page="followup">Ver todos los pendientes ${icon("arrow-right")}</button></article></section>`;
}
function quoteTable(quotes, compact = false) {
  return quotes.length
    ? `<div class="table-scroll"><table><thead><tr><th>Cotización / Cliente</th>${!compact ? "<th>Servicio</th>" : ""}<th>Estado</th><th>Importe</th>${!compact ? "<th>Seguimiento</th>" : ""}<th aria-label="Abrir"></th></tr></thead><tbody>${quotes
        .map((q) => {
          const c = clientFor(q);
          return `<tr><td><button class="cell-link" data-open="${q.id}"><span class="ref">${ref(q)}</span><strong>${h(c.name)}</strong><span>${h(compact ? q.service : q.title)}</span></button></td>${!compact ? `<td><span class="service-inline">${icon(serviceIcon(q.service))}${h(q.service)}</span></td>` : ""}<td>${badge(q.status)}</td><td><strong class="table-amount">${q.items.length ? money(total(q)) : "Por definir"}</strong><span class="cell-muted">${date(q.created_at)}</span></td>${!compact ? `<td><span class="${q.follow_up && q.follow_up < today() && !["Aceptada", "Rechazada", "Finalizada"].includes(q.status) ? "overdue" : ""}">${date(q.follow_up)}</span></td>` : ""}<td><button class="icon-btn" data-open="${q.id}" aria-label="Abrir ${ref(q)}">${icon("arrow-up-right")}</button></td></tr>`;
        })
        .join("")}</tbody></table></div>`
    : empty("No hay cotizaciones");
}
function filteredQuotes() {
  let list = db.quotes.filter(
    (q) =>
      (!status || q.status === status) &&
      (!service || q.service === service) &&
      `${q.title} ${ref(q)} ${clientFor(q).name} ${clientFor(q).company}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  list.sort((a, b) =>
    sort === "amount"
      ? total(b) - total(a)
      : b.created_at.localeCompare(a.created_at),
  );
  return list;
}
function quotesPage() {
  const list = filteredQuotes(),
    pages = Math.max(1, Math.ceil(list.length / 8));
  pageNumber = Math.min(pageNumber, pages);
  return `<section class="panel"><div class="filter-bar"><label class="search-box">${icon("search")}<input id="search" placeholder="Buscar cliente o cotización…" aria-label="Buscar cotizaciones" value="${h(query)}"/></label><select id="status-filter" aria-label="Filtrar por estado">${options(STATUSES, status, "Todos los estados")}</select><select id="service-filter" aria-label="Filtrar por servicio">${options(SERVICES, service, "Todos los servicios")}</select><button class="btn secondary" data-action="export">${icon("download")} Exportar</button></div><div class="list-summary"><span><strong>${list.length}</strong> cotizaciones</span><label>Ordenar por <select id="sort" aria-label="Ordenar cotizaciones"><option value="recent" ${sort === "recent" ? "selected" : ""}>Más recientes</option><option value="amount" ${sort === "amount" ? "selected" : ""}>Mayor importe</option></select></label></div>${quoteTable(list.slice((pageNumber - 1) * 8, pageNumber * 8))}<div class="pagination"><span>Página ${pageNumber} de ${pages}</span><div><button class="icon-btn" data-action="prev" ${pageNumber <= 1 ? "disabled" : ""} aria-label="Página anterior">${icon("chevron-left")}</button><button class="icon-btn" data-action="next" ${pageNumber >= pages ? "disabled" : ""} aria-label="Página siguiente">${icon("chevron-right")}</button></div></div></section>`;
}
function clientsPage() {
  const clients = db.clients.filter((c) =>
    `${c.name} ${c.company} ${c.email} ${c.phone}`
      .toLowerCase()
      .includes(query.toLowerCase()),
  );
  return `<section class="panel"><div class="filter-bar"><label class="search-box">${icon("search")}<input id="search" value="${h(query)}" placeholder="Buscar un cliente…" aria-label="Buscar clientes"/></label><span class="subtle-pill">${clients.length} clientes</span></div><div class="client-grid">${clients.map((c) => `<article class="client-card"><div class="client-card-top"><span class="avatar large">${h(initials(c.name))}</span>${canEdit() ? `<button class="icon-btn" data-edit-client="${c.id}" aria-label="Editar ${h(c.name)}">${icon("pencil")}</button>` : ""}</div><h3>${h(c.name)}</h3><p>${h(c.company || "Cliente particular")}</p><span class="contact-line">${icon("phone")}${h(c.phone)}</span><span class="contact-line">${icon("mail")}${h(c.email || "Sin correo registrado")}</span><span class="contact-line">${icon("map-pin")}${h(c.address || "Sin dirección registrada")}</span><button class="client-bottom" data-client-quotes="${c.id}">${db.quotes.filter((q) => q.client_id === c.id).length} cotizaciones ${icon("arrow-right")}</button></article>`).join("") || empty("No se encontraron clientes")}</div></section>`;
}
function followupPage() {
  return `<div class="follow-banner">${icon("calendar-clock")}<div><strong>${dueList().length} solicitudes requieren tu atención</strong><p>Prioriza los seguimientos de hoy y los que tienen una fecha vencida.</p></div></div><section class="panel"><div class="section-head"><h2>Solicitudes pendientes <span class="subtle-pill">${pendingList().length}</span></h2><button class="icon-btn" data-action="refresh" aria-label="Actualizar">${icon("refresh-cw")}</button></div>${quoteTable(pendingList())}</section>`;
}
function historyPage() {
  const events = [...db.events].sort((a, b) =>
    b.created_at.localeCompare(a.created_at),
  );
  return `<section class="panel"><div class="section-head"><div><h2>Registro de actividad</h2><p>Solicitudes, cambios de estado y notas del equipo.</p></div><span class="subtle-pill">${events.length} movimientos</span></div><div class="timeline global-timeline">${events.map(eventRow).join("") || empty("Aún no hay actividad")}</div></section>`;
}
function eventRow(e) {
  const q = db.quotes.find((q) => q.id === e.quote_id);
  return `<div class="timeline-item"><span class="timeline-icon">${icon(e.kind === "note" ? "message-circle" : "file-text")}</span><div><strong>${h(e.message)}</strong><p>${h(e.actor_name || "Equipo CLIMAXA")} · ${date(e.created_at)} ${new Date(e.created_at).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" })}</p>${e.snapshot ? `<span class="cell-muted">${h(e.snapshot.status)} · ${money(total(e.snapshot))} · Versión ${e.snapshot.version}</span>` : ""}${q ? `<button class="text-btn" data-open="${q.id}">${ref(q)} ${icon("arrow-up-right")}</button>` : ""}${e.snapshot ? `<button class="text-btn" data-print-event="${e.id}">Ver documento de esta versión ${icon("printer")}</button>` : ""}</div></div>`;
}
function teamPage() {
  return `<div class="notice">${icon("shield-check")}<p>El administrador gestiona el acceso; el perfil comercial registra y edita; el perfil de consulta puede leer y descargar documentos. ${api.demo ? "En la demostración no se modifican usuarios." : "Crea las cuentas desde Supabase → Authentication → Users y actívalas aquí."}</p></div><section class="panel"><div class="table-scroll"><table><thead><tr><th>Usuario</th><th>Perfil</th><th>Acceso</th><th></th></tr></thead><tbody>${db.profiles.map((p) => `<tr><td><strong>${h(p.name)}</strong><span class="cell-muted">${h(p.email)}</span></td><td>${roleName(p.role)}</td><td><span class="badge ${p.active ? "state-4" : "state-5"}">${p.active ? "Activo" : "Inactivo"}</span></td><td>${p.id !== profile.id ? `<button class="btn secondary" data-user="${p.id}">Administrar</button>` : "Tu cuenta"}</td></tr>`).join("")}</tbody></table></div></section>`;
}
function clientForm(id) {
  const c = db.clients.find((c) => c.id === id) || {};
  openModal(
    `${modalHeader("DIRECTORIO DE CLIENTES", id ? "Editar cliente" : "Nuevo cliente")}<form id="client-form" data-id="${id || ""}"><div class="form-grid"><label>Nombre completo *<input name="name" required maxlength="150" value="${h(c.name)}"/></label><label>Empresa<input name="company" maxlength="150" value="${h(c.company)}"/></label><label>Teléfono (con lada) *<input name="phone" type="tel" required pattern="[+0-9 ()-]{7,25}" title="Entre 7 y 25 caracteres: números, espacios, +, paréntesis o guiones" value="${h(c.phone)}"/></label><label>Correo electrónico<input name="email" type="email" maxlength="200" value="${h(c.email)}"/></label><label class="full">Dirección<input name="address" maxlength="500" value="${h(c.address)}"/></label></div><div class="form-error" role="alert"></div><div class="modal-footer"><button type="button" class="btn secondary" data-action="close">Cancelar</button><button class="btn primary" type="submit">${icon("check")} Guardar cliente</button></div></form>`,
  );
}
function itemRow(item = { description: "", quantity: 1, price: 0 }) {
  return `<div class="item-row"><input name="item-description" aria-label="Descripción del concepto" placeholder="Equipo, servicio o instalación" required maxlength="300" value="${h(item.description)}"/><input name="item-quantity" aria-label="Cantidad" type="number" step="0.01" min="0.01" max="100000" required value="${item.quantity}"/><input name="item-price" aria-label="Precio unitario" type="number" step="0.01" min="0" max="10000000" required value="${item.price}"/><button class="icon-btn" type="button" data-action="remove-item" aria-label="Eliminar concepto">${icon("x")}</button></div>`;
}
function quoteForm(id) {
  if (!db.clients.length) {
    toast("Registra primero un cliente.");
    clientForm();
    return;
  }
  const q = db.quotes.find((q) => q.id === id) || {
    status: STATUSES[0],
    priority: "Media",
    source: "WhatsApp",
    service: SERVICES[0],
    tax: 16,
    items: [],
    version: 0,
  };
  openModal(
    `${modalHeader(id ? `${ref(q)} · VERSIÓN ${q.version}` : "UNA NUEVA OPORTUNIDAD", id ? "Editar cotización" : "Nueva cotización")}<form id="quote-form" data-id="${id || ""}" data-version="${q.version}"><div class="form-grid"><label>Cliente *<select name="client_id" required><option value="">Seleccionar cliente</option>${db.clients.map((c) => `<option value="${c.id}" ${c.id === q.client_id ? "selected" : ""}>${h(c.name)}${c.company ? ` · ${h(c.company)}` : ""}</option>`).join("")}</select></label><label>Producto o servicio *<select name="service">${options(SERVICES, q.service)}</select></label><label class="full">Asunto de la solicitud *<input name="title" required maxlength="200" placeholder="Ej. Instalación de minisplit para oficina" value="${h(q.title)}"/></label><label class="full">Necesidades del cliente<textarea name="description" rows="3" maxlength="5000" placeholder="Describe el espacio, equipo y requerimientos…">${h(q.description)}</textarea></label><label>Estado<select name="status">${options(STATUSES, q.status)}</select></label><label>Canal de contacto<select name="source">${options(["WhatsApp", "Sitio web", "Teléfono", "Correo", "Presencial"], q.source)}</select></label><label>Prioridad<select name="priority">${options(["Baja", "Media", "Alta"], q.priority)}</select></label><label>Próximo seguimiento<input type="date" name="follow_up" value="${h(q.follow_up)}"/></label><label>Vigencia de la propuesta<input type="date" name="valid_until" value="${h(q.valid_until)}"/></label><label>IVA (%)<input id="tax" name="tax" type="number" step="0.01" min="0" max="100" required value="${q.tax}"/></label></div><div class="concept-header"><h3>Conceptos de la cotización</h3><button type="button" class="text-btn" data-action="add-item">${icon("plus")} Agregar concepto</button></div><p class="form-hint">Puedes registrar una solicitud sin importe y preparar la propuesta después. Moneda: MXN.</p><div class="item-labels"><span>Descripción</span><span>Cantidad</span><span>Precio unitario</span><span></span></div><div id="items">${q.items.map(itemRow).join("")}</div><div id="live-total" class="quote-totals"></div><div class="form-error" role="alert"></div><div class="modal-footer"><button type="button" class="btn secondary" data-action="close">Cancelar</button><button type="submit" class="btn primary">${icon("check")} Guardar cotización</button></div></form>`,
  );
  updateTotal();
}
function readItems() {
  return [...modal.querySelectorAll(".item-row")].map((row) => ({
    description: row.querySelector('[name="item-description"]').value.trim(),
    quantity: Number(row.querySelector('[name="item-quantity"]').value),
    price: Number(row.querySelector('[name="item-price"]').value),
  }));
}
function updateTotal() {
  const el = modal.querySelector("#live-total");
  if (!el) return;
  const t = totals(readItems(), modal.querySelector("#tax").value);
  el.innerHTML = `<span>Subtotal <strong>${money(t.subtotal)}</strong></span><span>IVA <strong>${money(t.tax)}</strong></span><span class="grand-total">Total <strong>${money(t.total)} <small>MXN</small></strong></span>`;
}
function detail(id) {
  const q = db.quotes.find((q) => q.id === id);
  if (!q) return;
  const c = clientFor(q),
    events = db.events
      .filter((e) => e.quote_id === id)
      .sort((a, b) => b.created_at.localeCompare(a.created_at));
  let phone = c.phone.replace(/\D/g, "");
  if (phone.length === 10) phone = `52${phone}`;
  openModal(
    `${modalHeader(`${ref(q)} · VERSIÓN ${q.version}`, h(q.title))}<div class="detail-body"><div class="detail-status">${badge(q.status)}<span>Prioridad ${h(q.priority)} · ${h(q.source)}</span></div><div class="detail-client"><div class="avatar large">${h(initials(c.name))}</div><div><strong>${h(c.name)}</strong><p>${h(c.company)} · ${h(c.phone)}</p><p>${h(c.email)}</p></div>${phone.length >= 7 ? `<a class="btn whatsapp" href="https://wa.me/${phone}?text=${encodeURIComponent(`Hola ${c.name}, te contactamos de CLIMAXA para dar seguimiento a tu solicitud ${ref(q)}.`)}" target="_blank" rel="noopener noreferrer">${icon("message-circle")} WhatsApp</a>` : ""}</div><p class="description">${h(q.description || "Sin descripción adicional.")}</p><div class="detail-meta"><span>Servicio<strong>${h(q.service)}</strong></span><span>Seguimiento<strong>${date(q.follow_up)}</strong></span><span>Vigencia<strong>${date(q.valid_until)}</strong></span><span>Total MXN<strong>${q.items.length ? money(total(q)) : "Por definir"}</strong></span></div><div class="detail-actions">${canEdit() ? `<button class="btn primary" data-edit-quote="${q.id}">${icon("pencil")} Editar cotización</button>` : ""}<button class="btn secondary" data-print="${q.id}">${icon("printer")} Documento / PDF</button></div><h3>Historial y seguimiento</h3>${canEdit() ? `<form id="note-form" data-id="${q.id}" class="note-form"><label class="sr-only" for="note">Nota de seguimiento</label><textarea id="note" name="note" required maxlength="2000" placeholder="Registra una llamada, un acuerdo o el siguiente paso…" rows="2"></textarea><button class="btn secondary" type="submit">Agregar nota</button><div class="form-error" role="alert"></div></form>` : ""}<div class="timeline">${events.map(eventRow).join("")}</div></div>`,
  );
}
function printQuote(q) {
  const c = q.client_snapshot || clientFor(q),
    t = totals(q.items, q.tax);
  openModal(
    `${modalHeader("DOCUMENTO DE COTIZACIÓN", "Vista del documento")}<div class="print-actions"><p>Selecciona «Guardar como PDF» en el cuadro de impresión de tu navegador.</p><button class="btn primary" data-action="print">${icon("printer")} Imprimir / Guardar PDF</button></div><article class="print-document"><div class="document-header"><img src="/logo.webp" alt="CLIMAXA"/><div><h2>${ref(q)}</h2><p>Versión ${q.version} · ${date(q.updated_at || q.created_at)}</p>${api.demo ? "<strong>DEMOSTRACIÓN · SIN VALIDEZ COMERCIAL</strong>" : ""}</div></div><h2>${h(q.title)}</h2><div class="document-info"><div><small>PREPARADA PARA</small><h3>${h(c.name)}</h3><p>${h(c.company)}<br/>${h(c.address)}<br/>${h(c.email)}<br/>${h(c.phone)}</p></div><div><small>DETALLES</small><p>${h(q.service)}<br/>Estado: ${h(q.status)}<br/>Vigencia: ${date(q.valid_until)}</p></div></div><p class="description">${h(q.description)}</p><table><thead><tr><th>Concepto</th><th>Cantidad</th><th>Precio unitario</th><th>Importe</th></tr></thead><tbody>${q.items.map((i) => `<tr><td>${h(i.description)}</td><td>${i.quantity}</td><td>${money(i.price)}</td><td>${money(Math.round(i.quantity * i.price * 100) / 100)}</td></tr>`).join("") || '<tr><td colspan="4">Importes por definir.</td></tr>'}</tbody></table><div class="quote-totals"><span>Subtotal <strong>${money(t.subtotal)}</strong></span><span>IVA (${q.tax}%) <strong>${money(t.tax)}</strong></span><span class="grand-total">Total MXN <strong>${money(t.total)}</strong></span></div><div class="document-footer">Gracias por confiar en CLIMAXA.<br/><span>Climatización y energía solar · www.climaxa.net</span><p>Propuesta comercial. Este documento no es una factura.</p></div></article>`,
  );
}
function userForm(id) {
  const p = db.profiles.find((p) => p.id === id);
  openModal(
    `${modalHeader("CONTROL DE ACCESO", h(p.name))}<form id="user-form" data-id="${p.id}"><div class="form-grid"><label>Perfil<select name="role"><option value="cliente" ${p.role === "cliente" ? "selected" : "disabled"}>Cliente</option><option value="admin" ${p.role === "cliente" ? "disabled" : ""} ${p.role === "admin" ? "selected" : ""}>Administrador</option><option value="comercial" ${p.role === "cliente" ? "disabled" : ""} ${p.role === "comercial" ? "selected" : ""}>Comercial</option><option value="consulta" ${p.role === "cliente" ? "disabled" : ""} ${p.role === "consulta" ? "selected" : ""}>Solo consulta</option></select></label><label>Acceso<select name="active"><option value="true" ${p.active ? "selected" : ""}>Activo</option><option value="false" ${!p.active ? "selected" : ""}>Inactivo</option></select></label></div><div class="form-error" role="alert"></div><div class="modal-footer"><button class="btn primary" type="submit">Guardar acceso</button></div></form>`,
  );
}
function exportCsv() {
  const rows = [
    ["Folio", "Cliente", "Servicio", "Estado", "Importe MXN", "Seguimiento"],
    ...filteredQuotes().map((q) => [
      ref(q),
      clientFor(q).name,
      q.service,
      q.status,
      q.items.length ? total(q) : "",
      q.follow_up || "",
    ]),
  ];
  const url = URL.createObjectURL(
    new Blob(
      ["\uFEFF" + rows.map((r) => r.map(csvCell).join(",")).join("\r\n")],
      { type: "text/csv;charset=utf-8" },
    ),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = `climaxa-cotizaciones-${today()}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("Archivo de cotizaciones exportado.");
}
function go(next) {
  page = next;
  query = "";
  status = "";
  service = "";
  pageNumber = 1;
  render();
  window.scrollTo(0, 0);
}
document.addEventListener("click", async (e) => {
  const el = e.target.closest("button,a");
  if (!el) return;
  try {
    if (el.dataset.page) {
      go(el.dataset.page);
      return;
    }
    if (el.dataset.open) {
      if (modal.open) closeModal();
      detail(el.dataset.open);
      return;
    }
    if (el.dataset.filterStatus) {
      go("quotes");
      status = el.dataset.filterStatus;
      render();
      return;
    }
    if (el.dataset.editClient) {
      clientForm(el.dataset.editClient);
      return;
    }
    if (el.dataset.editQuote) {
      closeModal();
      quoteForm(el.dataset.editQuote);
      return;
    }
    if (el.dataset.clientQuotes) {
      go("quotes");
      query = db.clients.find((c) => c.id === el.dataset.clientQuotes).name;
      render();
      return;
    }
    if (el.dataset.print) {
      const q = db.quotes.find((q) => q.id === el.dataset.print);
      closeModal();
      printQuote(q);
      return;
    }
    if (el.dataset.printEvent) {
      const q = db.events.find((v) => v.id === el.dataset.printEvent).snapshot;
      if (modal.open) closeModal();
      printQuote(q);
      return;
    }
    if (el.dataset.user) {
      userForm(el.dataset.user);
      return;
    }
    switch (el.dataset.action) {
      case "close":
        closeModal();
        break;
      case "menu":
        document.querySelector("#sidebar").classList.toggle("open");
        break;
      case "new-client":
        clientForm();
        break;
      case "new-quote":
        quoteForm();
        break;
      case "add-item":
        if (modal.querySelectorAll(".item-row").length >= 100)
          throw new Error("Máximo 100 conceptos.");
        modal
          .querySelector("#items")
          .insertAdjacentHTML("beforeend", itemRow());
        paintIcons();
        updateTotal();
        break;
      case "remove-item":
        el.closest(".item-row").remove();
        updateTotal();
        break;
      case "prev":
        pageNumber--;
        render();
        break;
      case "next":
        pageNumber++;
        render();
        break;
      case "export":
        exportCsv();
        break;
      case "print":
        window.print();
        break;
      case "refresh":
        await refresh();
        render();
        toast("Información actualizada.");
        break;
      case "logout":
        await api.signOut();
        profile = null;
        login();
        break;
      case "help":
        openModal(
          `${modalHeader("TU ESPACIO CLIMAXA", "De la solicitud al proyecto")}<div class="help-body"><p>1. Registra al cliente y sus datos de contacto.</p><p>2. Crea una solicitud y describe el producto o servicio.</p><p>3. Agrega conceptos y precios para elaborar la cotización.</p><p>4. Genera el PDF, envíalo por tu canal habitual y actualiza el estado.</p><p>5. Programa la próxima fecha de seguimiento y registra los acuerdos.</p><div class="notice">WhatsApp abre una conversación. El envío de documentos y la actualización del estado son manuales.</div></div>`,
        );
        break;
    }
  } catch (err) {
    toast(err.message, true);
  }
});
document.addEventListener("change", (e) => {
  if (e.target.id === "status-filter") status = e.target.value;
  else if (e.target.id === "service-filter") service = e.target.value;
  else if (e.target.id === "sort") sort = e.target.value;
  else return;
  pageNumber = 1;
  render();
});
let searchTimer;
document.addEventListener("input", (e) => {
  if (e.target.id === "search") {
    const position = e.target.selectionStart;
    query = e.target.value;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      pageNumber = 1;
      render();
      const input = document.querySelector("#search");
      input?.focus();
      input?.setSelectionRange(position, position);
    }, 180);
  }
  if (e.target.closest("#quote-form")) updateTotal();
});
document.addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  if (busy) return;
  busy = true;
  const submit = form.querySelector('[type="submit"]');
  if (submit) submit.disabled = true;
  const error = form.querySelector(".form-error");
  if (error) error.textContent = "";
  try {
    const data = Object.fromEntries(new FormData(form));
    if (form.id === "login-form") {
      await api.signIn(data.email, data.password);
      await boot();
      return;
    }
    if (!canEdit()) throw new Error("Tu perfil permite consultar información.");
    if (form.id === "client-form")
      await api.saveClient(data, form.dataset.id || undefined);
    else if (form.id === "quote-form") {
      const {
        client_id,
        title,
        service,
        status,
        source,
        priority,
        description,
        follow_up,
        valid_until,
        tax,
      } = data;
      await api.saveQuote(
        {
          client_id,
          title: title.trim(),
          service,
          status,
          source,
          priority,
          description,
          follow_up: follow_up || null,
          valid_until: valid_until || null,
          tax: Number(tax),
          items: readItems(),
        },
        form.dataset.id || undefined,
        Number(form.dataset.version),
      );
    } else if (form.id === "note-form")
      await api.addNote(form.dataset.id, data.note.trim());
    else if (form.id === "user-form")
      await api.updateUser(form.dataset.id, data.role, data.active === "true");
    await refresh();
    closeModal();
    render();
    if (form.id === "note-form") detail(form.dataset.id);
    toast("Cambios guardados.");
  } catch (err) {
    if (error) error.textContent = err.message;
    else toast(err.message, true);
  } finally {
    busy = false;
    if (submit) submit.disabled = false;
  }
});
function login(message = "") {
  app.innerHTML = `<main class="login-layout"><section class="login-brand"><img src="/logo.webp" alt="CLIMAXA"/><div><span class="eyebrow">GESTIÓN COMERCIAL</span><h1>Conecta cada solicitud<br/>con una oportunidad.</h1><p>Clientes, cotizaciones y seguimiento, en un solo lugar.</p></div><span>Climatización y energía solar</span></section><section class="login-panel"><div><h2>Bienvenido a CLIMAXA</h2><p>Ingresa a tu espacio de trabajo.</p>${!api.configured ? '<div class="notice">Configura Supabase para habilitar el acceso. Consulta la guía de publicación incluida en el proyecto.</div>' : `<form id="login-form"><label>Correo electrónico<input type="email" name="email" autocomplete="username" required/></label><label>Contraseña<input type="password" name="password" autocomplete="current-password" required/></label><div class="form-error" role="alert">${h(message)}</div><button class="btn primary" type="submit">Iniciar sesión ${icon("arrow-right")}</button></form><p class="form-hint">¿Necesitas acceso o recuperar tu contraseña? Contacta al administrador de CLIMAXA.</p>`}</div></section></main>`;
  paintIcons();
}
async function boot() {
  app.innerHTML = '<div class="loading">Cargando tu espacio CLIMAXA…</div>';
  try {
    profile = await api.session();
    if (!profile) {
      login();
      return;
    }
    if (profile.role === "cliente") {
      window.location.replace("/#cuenta");
      return;
    }
    await refresh();
    render();
  } catch (err) {
    await api.signOut().catch(() => {});
    login(err.message);
    toast(err.message, true);
  }
}
void boot();
