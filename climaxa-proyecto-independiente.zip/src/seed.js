import { today } from "./domain.js";
export function seed() {
  const shift = (days) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 10);
  };
  const names = [
    ["Mariana López", "Residencial Las Palmas"],
    ["Roberto Méndez", "Café Horizonte"],
    ["Ana Sofía García", "Consultorio Dental"],
    ["Carlos Hernández", "Casa particular"],
    ["Valeria Torres", "Hotel Los Olivos"],
    ["Diego Ramírez", "Oficinas Norte"],
  ];
  const clients = names.map(([name, company], i) => ({
    id: crypto.randomUUID(),
    name,
    company,
    email: `cliente${i + 1}@example.com`,
    phone: `22800000${10 + i}`,
    address: "Xalapa, Veracruz",
    created_at: new Date().toISOString(),
  }));
  const rows = [
    [
      "Sistema de climatización residencial",
      "Aire acondicionado",
      "Nueva solicitud",
      0,
      0,
      "Alta",
      0,
    ],
    [
      "Mantenimiento de equipos minisplit",
      "Mantenimiento",
      "En revisión",
      1,
      1850,
      "Media",
      -1,
    ],
    [
      "Instalación de minisplit inverter",
      "Instalación",
      "En elaboración",
      2,
      12400,
      "Alta",
      1,
    ],
    [
      "Sistema fotovoltaico de 6 paneles",
      "Paneles solares",
      "Cotización enviada",
      3,
      48500,
      "Media",
      0,
    ],
    [
      "Climatización de habitaciones",
      "Aire acondicionado",
      "Aceptada",
      4,
      32800,
      "Media",
      3,
    ],
    [
      "Servicio preventivo de oficina",
      "Mantenimiento",
      "Finalizada",
      5,
      3200,
      "Baja",
      -3,
    ],
    [
      "Ampliación de sistema solar",
      "Paneles solares",
      "Cotización enviada",
      0,
      27900,
      "Media",
      2,
    ],
    [
      "Reemplazo de aire acondicionado",
      "Aire acondicionado",
      "Rechazada",
      1,
      15200,
      "Baja",
      -4,
    ],
    [
      "Revisión de equipo en recepción",
      "Mantenimiento",
      "Nueva solicitud",
      4,
      0,
      "Media",
      1,
    ],
  ];
  const quotes = rows.map(
    ([title, service, status, c, price, priority, day], i) => ({
      id: crypto.randomUUID(),
      number: 1042 - i,
      client_id: clients[c].id,
      title,
      service,
      status,
      priority,
      source: i % 2 ? "Sitio web" : "WhatsApp",
      description:
        "Solicitud de ejemplo para explorar el sistema. Confirmar las necesidades y condiciones de instalación con el cliente.",
      items: price ? [{ description: title, quantity: 1, price }] : [],
      tax: 16,
      follow_up: shift(day),
      valid_until: shift(15),
      created_at: `${shift(-i)}T10:00:00Z`,
      updated_at: `${shift(-i)}T10:00:00Z`,
      version: 1,
    }),
  );
  const profile = {
    id: crypto.randomUUID(),
    name: "Andrea Martínez",
    email: "demo@example.com",
    role: "admin",
    active: true,
  };
  const events = quotes.map((q) => ({
    id: crypto.randomUUID(),
    quote_id: q.id,
    kind: "created",
    message: "Solicitud registrada",
    actor_name: profile.name,
    created_at: q.created_at,
    snapshot: {
      ...structuredClone(q),
      client_snapshot: structuredClone(
        clients.find((c) => c.id === q.client_id),
      ),
    },
  }));
  return {
    clients,
    quotes,
    profiles: [profile],
    events,
    profile,
    seed_date: today(),
  };
}
