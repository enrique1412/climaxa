import "./public.css";
import {
  createIcons,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  FileText,
  LogOut,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  ShieldCheck,
  Snowflake,
  Sun,
  UserRound,
  Wrench,
  X,
  Printer,
} from "lucide";
import * as api from "./customer-data.js";
import {
  escapeHtml as h,
  SERVICES,
  STATUSES,
  money,
  totals,
  date,
} from "./domain.js";
const icons = {
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  FileText,
  LogOut,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  ShieldCheck,
  Snowflake,
  Sun,
  UserRound,
  Wrench,
  X,
  Printer,
};
const icon = (n) => `<i data-lucide="${n}" aria-hidden="true"></i>`;
const root = document.querySelector("#public-app"),
  dialog = document.querySelector("#customer-dialog");
let profile = null,
  customerData = null,
  submitting = false,
  requestKey = crypto.randomUUID(),
  claimToken = api.receiptToken(),
  registrationPrefill = {},
  accountWarning = "";
const wa = "https://wa.me/522281996034";
const paint = () => createIcons({ icons, attrs: { "stroke-width": 1.7 } });
function toast(message) {
  const node = document.querySelector("#public-toast");
  node.textContent = message;
  node.className = "show";
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (node.className = ""), 6000);
}
function header() {
  return `<header class="site-header"><a class="site-logo" href="/" aria-label="CLIMAXA, inicio"><img src="/logo.webp" alt="CLIMAXA"/></a><button class="menu-toggle" data-action="menu" aria-label="Abrir menú" aria-expanded="false">${icon("menu")}</button><nav id="site-nav" aria-label="Navegación principal"><a href="/#inicio">Inicio</a><a href="/#nosotros">Quiénes somos</a><a href="/#servicios">Servicios ${icon("chevron-down")}</a><a href="/#cuenta" class="account-link">${icon("user-round")}${profile?.role === "cliente" ? "Mi cuenta" : "Acceso clientes"}</a><a href="/#cotizar" class="button nav-quote">Solicitar cotización ${icon("arrow-up-right")}</a></nav></header>${api.demo ? '<div class="demo-banner">Vista de demostración · Usa datos ficticios. Las solicitudes se guardan solo en este navegador.</div>' : ""}`;
}
function footer() {
  return `<footer class="site-footer"><div class="footer-brand"><img src="/logo.webp" alt="CLIMAXA"/><p>El confort que necesitas.<br/>La energía que transforma tu espacio.</p></div><div><strong>Estamos para ayudarte</strong><a href="tel:2286888910">${icon("phone")} 228 688 8910</a><a href="${wa}" target="_blank" rel="noopener noreferrer">${icon("message-circle")} Escríbenos por WhatsApp</a><span>${icon("map-pin")} Xalapa, Veracruz</span></div><div><strong>Tu espacio CLIMAXA</strong><a href="/#cotizar">Solicitar cotización</a><a href="/#cuenta">Mi cuenta</a><button data-action="privacy">Uso de tus datos</button><a href="/equipo.html">Acceso del equipo ${icon("arrow-up-right")}</a></div><div class="footer-bottom"><span>© ${new Date().getFullYear()} CLIMAXA. Todos los derechos reservados.</span><span>Climatización y energía solar</span></div></footer>`;
}
function marketing() {
  return `<main><section id="inicio" class="hero"><div class="hero-shade"></div><div class="hero-content"><span class="hero-label"><span></span> CONFORT Y ENERGÍA PARA TU VIDA</span><h1>Tu espacio ideal.<br/>Comienza con<br/><span>el mejor clima.</span></h1><p>Expertos en aire acondicionado y paneles solares.<br class="desktop-only"/> Venta, instalación y mantenimiento para tu hogar o negocio.</p><div class="hero-actions"><a href="#cotizar" class="button white">Cotiza tu proyecto ${icon("arrow-up-right")}</a><a href="#servicios" class="hero-text-link">Descubre nuestros servicios ${icon("arrow-right")}</a></div><div class="hero-trust">${icon("shield-check")} Atención personalizada <span></span> Soluciones para cada espacio</div></div><div class="hero-caption"><span>CLIMATIZACIÓN + ENERGÍA SOLAR</span><strong>Bienestar que se siente.<br/>Eficiencia que se nota.</strong></div><span class="hero-index">DISEÑADO PARA TU BIENESTAR</span></section><section class="benefit-strip" aria-label="Beneficios"><div>${icon("snowflake")}<span>Confort en cada espacio</span></div><div>${icon("sun")}<span>Energía más eficiente</span></div><div>${icon("wrench")}<span>Servicio especializado</span></div><div>${icon("shield-check")}<span>Atención de principio a fin</span></div></section><section id="servicios" class="services section-wrap"><div class="section-heading"><div><span class="kicker">SOLUCIONES A TU MEDIDA</span><h2>Un mejor ambiente.<br/>Muchas formas de lograrlo.</h2></div><p>Te acompañamos a elegir la solución adecuada<br class="desktop-only"/> para tu hogar, negocio o industria.</p></div><div class="service-cards"><article class="service-card"><div class="service-image air"><span>01</span>${icon("snowflake")}</div><div class="service-content"><h3>Aire acondicionado</h3><p>Encuentra el equipo ideal para disfrutar de un ambiente fresco y confortable.</p><a href="#cotizar" data-service="Aire acondicionado">Quiero climatizar mi espacio ${icon("arrow-up-right")}</a></div></article><article class="service-card"><div class="service-image solar"><span>02</span>${icon("sun")}</div><div class="service-content"><h3>Paneles solares</h3><p>Aprovecha la energía del sol con una solución diseñada para tus necesidades.</p><a href="#cotizar" data-service="Paneles solares">Quiero aprovechar el sol ${icon("arrow-up-right")}</a></div></article><article class="service-card"><div class="service-image maintenance"><span>03</span>${icon("wrench")}</div><div class="service-content"><h3>Instalación y mantenimiento</h3><p>Cuida el rendimiento de tus equipos con atención y servicio especializado.</p><a href="#cotizar" data-service="Mantenimiento">Quiero cuidar mis equipos ${icon("arrow-up-right")}</a></div></article></div></section><section id="nosotros" class="about-section section-wrap"><div class="about-mark">${icon("snowflake")}<span>CLIMAXA</span><small>CONEXIONES QUE GENERAN BIENESTAR</small></div><div><span class="kicker">MÁS QUE EQUIPOS, SOLUCIONES</span><h2>Escuchamos tu proyecto.<br/>Cuidamos cada detalle.</h2><p>Cada espacio es diferente. En CLIMAXA te ayudamos a encontrar la solución de climatización o energía solar que se adapta a lo que necesitas.</p><div class="about-checks"><span>${icon("check")} Asesoría personalizada</span><span>${icon("check")} Seguimiento de tu cotización</span><span>${icon("check")} Servicios para hogares y negocios</span></div></div></section><section id="cotizar" class="quote-section"><div class="section-wrap quote-layout"><div class="quote-intro"><span class="kicker">HABLEMOS DE TU PROYECTO</span><h2>Tu próxima solución<br/>empieza aquí<span>.</span></h2><p>Cuéntanos qué necesitas. Nuestro equipo revisará tu solicitud y se pondrá en contacto contigo para preparar una propuesta.</p><div class="steps"><div><span>01</span><p><strong>Cuéntanos tu idea</strong>Comparte los detalles de tu espacio.</p></div><div><span>02</span><p><strong>Recibe atención personalizada</strong>Te ayudamos a definir la mejor solución.</p></div><div><span>03</span><p><strong>Dale seguimiento a tu proyecto</strong>Crea una cuenta si quieres consultar tus solicitudes.</p></div></div><div class="whatsapp-card">${icon("message-circle")}<div><strong>¿Prefieres conversar?</strong><a href="${wa}" target="_blank" rel="noopener noreferrer">Escríbenos por WhatsApp ${icon("arrow-up-right")}</a></div></div></div><div id="request-container" class="request-card">${requestForm()}</div></div></section><section class="account-invite section-wrap"><div class="invite-icon">${icon("user-round")}</div><div><span class="kicker">TU PRÓXIMO PROYECTO, MÁS FÁCIL</span><h2>Un espacio para ti. Siempre a mano.</h2><p>Con tu cuenta guardas tus datos y consultas tus solicitudes cuando lo necesites.</p></div><a href="#registro" class="button outline">Crear mi cuenta ${icon("arrow-right")}</a></section></main>`;
}
function contactFields(data = {}, prefix = "") {
  return `<label>Nombre completo *<input name="name" autocomplete="name" required maxlength="150" value="${h(data.name || "")}" placeholder="¿Cómo te llamas?"/></label><label>Teléfono *<input name="phone" autocomplete="tel" type="tel" required pattern="[+0-9 ()-]{7,25}" maxlength="25" value="${h(data.phone || "")}" placeholder="Ej. 228 123 4567"/></label><label class="wide">Correo electrónico *<input name="email" type="email" autocomplete="email" required maxlength="200" value="${h(data.email || "")}" placeholder="tucorreo@ejemplo.com"/></label>${prefix === "register" ? "" : `<label class="wide">Empresa o negocio <span>(opcional)</span><input name="company" maxlength="150" value="${h(data.company || "")}" placeholder="Nombre de tu empresa"/></label>`}`;
}
function requestForm() {
  const member = profile?.role === "cliente";
  return `<span class="form-kicker">SIN COMPROMISO</span><h3>Solicita tu cotización</h3><p class="form-description">${member ? `Hola, ${h(profile.name)}. Utilizaremos los datos de tu cuenta.` : "No necesitas una cuenta para dar el primer paso."}</p><form id="request-form"><div class="fields">${member ? "" : contactFields()}<label class="wide">¿Qué servicio necesitas? *<select name="service" required><option value="">Selecciona un servicio</option>${SERVICES.map((s) => `<option>${s}</option>`).join("")}</select></label><label class="wide">¿Cuál es tu proyecto? *<input name="title" maxlength="200" required placeholder="Ej. Aire acondicionado para mi sala"/></label><label class="wide">Cuéntanos un poco más<textarea name="description" rows="3" maxlength="5000" placeholder="Tipo de espacio, equipos, ubicación o detalles que debamos conocer…"></textarea></label></div>${member ? "" : `<label class="check-label"><input type="checkbox" name="contact_consent" required/><span>Autorizo a CLIMAXA a usar estos datos para atender mi solicitud. <button type="button" data-action="privacy">Ver uso de datos</button></span></label><label class="account-optin"><input type="checkbox" name="create_account"/><span><strong>Quiero guardar mis datos para futuras visitas</strong><small>Al enviar podrás crear una cuenta. Es opcional.</small></span>${icon("user-round")}</label>`}<div class="form-error" role="alert"></div><button class="button primary full" type="submit">Enviar solicitud ${icon("arrow-right")}</button><p class="form-footnote">${icon("shield-check")} Tus datos se utilizan para atender tu proyecto.</p></form>`;
}
function accountPage(mode) {
  const register = mode === "registro";
  if (profile && mode === "cuenta") {
    if (profile.role !== "cliente")
      return `<main class="auth-section"><div class="auth-card"><h1>Esta es una cuenta del equipo</h1><p>Continúa en el espacio de gestión comercial.</p><a class="button primary" href="/equipo.html">Abrir panel del equipo</a></div></main>`;
    return portal();
  }
  return `<main class="auth-section"><div class="auth-aside"><span class="kicker">TU ESPACIO CLIMAXA</span><h1>${register ? "Hoy una idea.<br/>Mañana, otro proyecto." : "Qué gusto<br/>tenerte de vuelta."}</h1><p>Conserva tus datos, consulta tus solicitudes y encuentra tus propuestas en un mismo lugar.</p><ul><li>${icon("check-circle-2")} Tus cotizaciones, siempre a mano</li><li>${icon("check-circle-2")} Menos datos que llenar la próxima vez</li><li>${icon("check-circle-2")} Acceso solo a tu información</li></ul><a href="/#cotizar">También puedes cotizar sin cuenta ${icon("arrow-right")}</a></div><div class="auth-card"><span class="form-kicker">${register ? "CREA TU CUENTA" : "ACCESO CLIENTES"}</span><h2>${register ? "Un espacio para tus proyectos" : "Inicia sesión"}</h2><p>${register ? "Regístrate si deseas conservar tus datos para futuras solicitudes." : "Consulta el estado de tus solicitudes y tus cotizaciones."}</p>${api.demo ? '<div class="inline-note">Demostración: usa un correo ficticio. No se utilizan contraseñas ni se envían correos.</div>' : ""}<form id="${register ? "register" : "signin"}-form"><div class="fields">${register ? contactFields(registrationPrefill, "register") : '<label class="wide">Correo electrónico<input name="email" type="email" autocomplete="username" required/></label>'}${!api.demo ? `<label class="wide">Contraseña${register ? " (mínimo 8 caracteres)" : ""}<input name="password" type="password" autocomplete="${register ? "new-password" : "current-password"}" minlength="8" maxlength="128" required/></label>` : ""}</div>${register ? '<label class="check-label"><input name="account_consent" type="checkbox" required/><span>Quiero crear una cuenta y autorizo conservar mis datos para consultar y dar seguimiento a mis solicitudes. <button type="button" data-action="privacy">Ver uso de datos</button></span></label>' : ""}<div class="form-error" role="alert"></div><button class="button primary full" type="submit">${register ? "Crear mi cuenta" : "Iniciar sesión"} ${icon("arrow-right")}</button></form><p class="auth-switch">${register ? '¿Ya tienes cuenta? <a href="#cuenta">Inicia sesión</a>' : '¿Es tu primera visita? <a href="#registro">Crea tu cuenta</a>'}</p>${!register && !api.demo ? '<a class="recover-link" href="#recuperar">Olvidé mi contraseña</a>' : ""}</div></main>`;
}
function portal() {
  const { account, quotes } = customerData;
  return `<main class="portal section-wrap"><div class="portal-heading"><div><span class="kicker">MI ESPACIO CLIMAXA</span><h1>Hola, ${h(account.name.split(" ")[0])}<span>.</span></h1><p>Tu próximo proyecto comienza con una buena conexión.</p></div><button class="button outline" data-action="logout">${icon("log-out")} Cerrar sesión</button></div>${accountWarning ? `<div class="inline-note" role="status">${h(accountWarning)}</div>` : ""}<div class="portal-grid"><aside class="customer-profile"><span class="profile-icon">${icon("user-round")}</span><h2>${h(account.name)}</h2><span class="customer-label">${quotes.length > 1 ? "Cliente frecuente" : "Cliente registrado"}</span><p>${h(account.email)}</p><p>${h(account.phone)}</p><div class="saved-data">${icon("check-circle-2")} Tus datos están guardados para próximas solicitudes.</div><a href="/#cotizar" class="button primary full">Nueva solicitud ${icon("arrow-right")}</a><a class="profile-contact" href="${wa}" target="_blank" rel="noopener noreferrer">¿Necesitas actualizar tus datos?</a></aside><section class="customer-quotes"><div class="quotes-heading"><h2>Mis solicitudes <span>${quotes.length}</span></h2><button data-action="refresh" class="text-button">Actualizar</button></div>${quotes.length ? quotes.map((q) => `<article class="customer-quote"><div class="quote-top"><span>COT-${q.number}</span><span class="status status-${STATUSES.indexOf(q.status)}">${h(q.status)}</span></div><h3>${h(q.title)}</h3><p>${h(q.service)} <span>·</span> ${date(q.created_at)}</p><div class="quote-bottom"><span>${q.items.length ? `<strong>${money(totals(q.items, q.tax).total)}</strong> MXN` : "Estamos preparando tu propuesta."}</span><button class="text-button" data-quote="${q.id}">Ver solicitud ${icon("arrow-up-right")}</button></div></article>`).join("") : `<div class="empty-quotes">${icon("file-text")}<h3>Este es el comienzo de tu próximo proyecto</h3><p>Cuando envíes una solicitud con tu cuenta, aparecerá aquí.</p><a href="/#cotizar" class="button primary">Solicitar una cotización ${icon("arrow-right")}</a></div>`}</section></div></main>`;
}
function recoveryPage() {
  return `<main class="auth-section single"><div class="auth-card"><span class="kicker">RECUPERA TU ACCESO</span><h1>¿Olvidaste tu contraseña?</h1><p>Te enviaremos un enlace para elegir una nueva contraseña.</p><form id="recover-form"><label>Correo electrónico<input type="email" name="email" required autocomplete="email"/></label><div class="form-error" role="alert"></div><button class="button primary full" type="submit">Enviar enlace ${icon("arrow-right")}</button></form><a href="#cuenta" class="recover-link">Volver al inicio de sesión</a></div></main>`;
}
function passwordPage() {
  return `<main class="auth-section single"><div class="auth-card"><h1>Elige tu nueva contraseña</h1><form id="password-form"><label>Nueva contraseña<input type="password" name="password" required minlength="8" maxlength="128" autocomplete="new-password"/></label><div class="form-error" role="alert"></div><button class="button primary full" type="submit">Guardar contraseña</button></form></div></main>`;
}
function route() {
  const hash = location.hash.slice(1);
  return ["cuenta", "registro", "recuperar"].includes(hash) ? hash : "home";
}
function render() {
  const mode = route();
  root.innerHTML =
    header() +
    (new URLSearchParams(location.search).has("recuperar") && profile
      ? passwordPage()
      : mode === "home"
        ? marketing()
        : mode === "recuperar"
          ? recoveryPage()
          : accountPage(mode)) +
    footer();
  paint();
}
async function boot() {
  try {
    profile = await api.customerSession();
    if (profile?.role === "cliente") {
      try {
        await api.claimRequest();
        accountWarning = "";
      } catch (err) {
        accountWarning = err.message;
      }
      customerData = await api.accountData();
    } else customerData = null;
    render();
    if (route() === "home" && location.hash)
      document.getElementById(location.hash.slice(1))?.scrollIntoView();
  } catch (err) {
    profile = null;
    customerData = null;
    render();
    toast(err.message);
  }
}
let currentRoute = route();
window.addEventListener("hashchange", async () => {
  const next = route();
  document.querySelector("#site-nav")?.classList.remove("open");
  if (next !== currentRoute) {
    currentRoute = next;
    await boot();
    window.scrollTo(0, 0);
    if (next === "home" && location.hash)
      document.getElementById(location.hash.slice(1))?.scrollIntoView();
  }
});
function modal(title, body) {
  dialog.innerHTML = `<div class="dialog-head"><h2 id="dialog-title">${title}</h2><button data-action="close" aria-label="Cerrar">${icon("x")}</button></div>${body}`;
  dialog.showModal();
  paint();
}
function quoteDocument(id) {
  const q = customerData.quotes.find((q) => q.id === id);
  if (!q) return;
  const t = totals(q.items, q.tax || 0);
  modal(
    `COT-${q.number}`,
    `<div class="customer-document"><img src="/logo.webp" alt="CLIMAXA"/><span class="status status-${STATUSES.indexOf(q.status)}">${h(q.status)}</span><h2>${h(q.title)}</h2><p>${h(customerData.account.name)} · ${h(q.service)}</p><p>Fecha: ${date(q.created_at)} · Versión ${q.version}</p>${api.demo ? "<p>DEMOSTRACIÓN · SIN VALIDEZ COMERCIAL</p>" : ""}${q.items.length ? `<div class="document-table"><table><thead><tr><th>Concepto</th><th>Cant.</th><th>Precio</th><th>Importe</th></tr></thead><tbody>${q.items.map((i) => `<tr><td>${h(i.description)}</td><td>${i.quantity}</td><td>${money(i.price)}</td><td>${money(Math.round(i.price * i.quantity * 100) / 100)}</td></tr>`).join("")}</tbody></table></div><div class="customer-totals"><p>Subtotal <strong>${money(t.subtotal)}</strong></p><p>IVA (${q.tax}%) <strong>${money(t.tax)}</strong></p><p>Total MXN <strong>${money(t.total)}</strong></p></div><p>Vigencia: ${date(q.valid_until)}</p><button class="button primary no-print" data-action="print">${icon("printer")} Imprimir / Guardar PDF</button><p class="no-print small">Elige «Guardar como PDF» en las opciones de impresión.</p>` : '<div class="inline-note">Tu solicitud está registrada. Aquí podrás consultar el importe cuando el equipo comparta la propuesta.</div>'}<p class="document-sign">Gracias por confiar en CLIMAXA.<br/>Esta propuesta no es una factura.</p></div>`,
  );
}
document.addEventListener("click", async (e) => {
  const el = e.target.closest("a,button");
  if (!el) return;
  if (el.tagName === "A" && el.getAttribute("href")?.includes("#")) {
    document.querySelector("#site-nav")?.classList.remove("open");
    document
      .querySelector(".menu-toggle")
      ?.setAttribute("aria-expanded", "false");
  }
  if (el.dataset.service) {
    const service = el.dataset.service;
    if (route() !== "home") {
      location.hash = "cotizar";
      return;
    }
    const field = document.querySelector('[name="service"]');
    if (field) field.value = service;
  }
  try {
    if (el.dataset.quote) {
      quoteDocument(el.dataset.quote);
      return;
    }
    switch (el.dataset.action) {
      case "menu": {
        const nav = document.querySelector("#site-nav");
        nav.classList.toggle("open");
        el.setAttribute(
          "aria-expanded",
          String(nav.classList.contains("open")),
        );
        break;
      }
      case "close":
        dialog.close();
        break;
      case "print":
        window.print();
        break;
      case "logout":
        await api.logout();
        profile = null;
        customerData = null;
        location.hash = "cuenta";
        await boot();
        break;
      case "refresh":
        await boot();
        toast("Tus solicitudes están actualizadas.");
        break;
      case "privacy":
        modal(
          "Uso de tus datos",
          `<div class="privacy-body"><p>Los datos que compartas se utilizarán para atender tu solicitud de cotización y comunicarnos contigo sobre tu proyecto.</p><h3>Crear una cuenta es opcional</h3><p>Si autorizas crearla, conservaremos tus datos de contacto y tus solicitudes para facilitar futuras visitas. Esto no implica autorizar publicidad.</p><h3>Tu información, en tu cuenta</h3><p>Podrás consultar tus solicitudes; el equipo de CLIMAXA tendrá acceso para atenderlas. Para solicitar correcciones, información o eliminación de tu cuenta, comunícate con CLIMAXA.</p><a class="button outline" href="${wa}" target="_blank" rel="noopener noreferrer">Contactar a CLIMAXA ${icon("message-circle")}</a></div>`,
        );
        break;
    }
  } catch (err) {
    toast(err.message);
  }
});
dialog.addEventListener("click", (e) => {
  if (e.target === dialog) dialog.close();
});
document.addEventListener("submit", async (e) => {
  const form = e.target;
  if (
    ![
      "request-form",
      "register-form",
      "signin-form",
      "recover-form",
      "password-form",
    ].includes(form.id)
  )
    return;
  e.preventDefault();
  if (submitting) return;
  submitting = true;
  const button = form.querySelector('[type="submit"]');
  button.disabled = true;
  const error = form.querySelector(".form-error");
  error.textContent = "";
  const values = Object.fromEntries(new FormData(form));
  try {
    if (form.id === "request-form") {
      const receipt = await api.submitRequest(
        { ...values, contact_consent: values.contact_consent === "on" },
        requestKey,
        claimToken,
      );
      const member = profile?.role === "cliente";
      if (!member) api.rememberClaim({ key: requestKey, token: claimToken });
      registrationPrefill = values;
      document.querySelector("#request-container").innerHTML =
        `<div class="request-success" role="status">${icon("check-circle-2")}<span class="form-kicker">EL PRIMER PASO ESTÁ DADO</span><h3>¡Recibimos tu solicitud!</h3><span class="receipt">COT-${receipt.number}</span><p>El equipo de CLIMAXA revisará tu proyecto y se pondrá en contacto contigo.</p>${member ? '<a class="button primary full" href="#cuenta">Consultar mis solicitudes</a>' : `<div class="success-account"><h4>${values.create_account ? "Ahora, guarda tu próximo paso" : "¿Quieres darle seguimiento desde tu cuenta?"}</h4><p>Si lo deseas, crea una cuenta con el mismo correo. Después de verificarlo podrás consultar esta solicitud y reutilizar tus datos.</p><a class="button primary full" href="#registro">Crear mi cuenta ${icon("arrow-right")}</a><a href="#cuenta">Ya tengo cuenta</a></div>`}<a href="${wa}" target="_blank" rel="noopener noreferrer" class="text-button">También puedes escribirnos por WhatsApp ${icon("arrow-up-right")}</a></div>`;
      paint();
      requestKey = crypto.randomUUID();
      claimToken = api.receiptToken();
      document
        .querySelector("#request-container")
        .scrollIntoView({ block: "center", behavior: "smooth" });
    } else if (form.id === "register-form") {
      const result = await api.registerAccount({
        ...values,
        account_consent: values.account_consent === "on",
      });
      if (result.confirmed) {
        location.hash = "cuenta";
        await boot();
      } else {
        form.parentElement.innerHTML = `<div class="request-success">${icon("check-circle-2")}<h2>Revisa tu correo</h2><p>Si tu dirección permite crear una cuenta, recibirás un enlace de confirmación. Ábrelo para activar tu acceso.</p><p>Si ya tenías una cuenta, inicia sesión con el mismo correo para vincular la solicitud que acabas de enviar.</p><a class="button primary" href="#cuenta">Ir a iniciar sesión</a></div>`;
        paint();
      }
    } else if (form.id === "signin-form") {
      await api.login(values.email, values.password);
      await boot();
    } else if (form.id === "recover-form") {
      await api.recover(values.email);
      form.innerHTML =
        '<div class="inline-note" role="status">Si el correo corresponde a una cuenta, recibirás un enlace para recuperar tu acceso.</div>';
    } else if (form.id === "password-form") {
      await api.changePassword(values.password);
      history.replaceState(null, "", "/#cuenta");
      await boot();
      toast("Contraseña actualizada.");
    }
  } catch (err) {
    error.textContent = err.message;
  } finally {
    submitting = false;
    button.disabled = false;
  }
});
void boot();
