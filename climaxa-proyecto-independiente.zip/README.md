# CLIMAXA · Sitio público y gestión de cotizaciones

Proyecto independiente en **HTML, CSS y JavaScript**, con **Supabase (PostgreSQL + Auth)** para cuentas y datos. Está preparado para subirlo a un nuevo repositorio. Este directorio tiene un repositorio Git local, pero aún no tiene un remoto de GitHub ni un despliegue permanente.

## Las tres vistas

| Dirección                 | Uso                                                                                |
| ------------------------- | ---------------------------------------------------------------------------------- |
| `/`                       | Página pública: servicios, información y solicitud de cotización sin cuenta        |
| `/#registro` y `/#cuenta` | Registro opcional, acceso e historial del cliente                                  |
| `/equipo.html`            | Panel privado de clientes, cotizaciones, seguimiento, notas, documentos y usuarios |

### Recorrido del cliente

1. Puede enviar una solicitud **sin crear una cuenta**. Debe autorizar el uso de sus datos para atenderla.
2. Si lo desea, crea una cuenta con una autorización independiente, sin casillas preseleccionadas. No es una autorización de publicidad.
3. Confirma su correo e inicia sesión. La solicitud enviada como invitado se vincula mediante un identificador secreto y el mismo correo verificado. Conocer el correo de otra persona no permite acceder a sus solicitudes.
4. Consulta sus solicitudes, estados y propuestas publicadas, y puede imprimirlas o guardarlas como PDF.
5. Las nuevas solicitudes reutilizan sus datos. Con más de una solicitud aparece la etiqueta **Cliente frecuente**; es una etiqueta informativa, no un programa de descuentos.

El equipo recibe las solicitudes en el mismo panel. Las cuentas de clientes no tienen acceso a notas internas, datos de otros clientes, borradores de precios ni administración. Los conceptos e importes aparecen para el cliente cuando el equipo marca la propuesta como **Cotización enviada**, Aceptada, Rechazada o Finalizada. Las modificaciones de estado siguen a cargo del equipo; el portal no constituye una firma electrónica.

## Ejecutar la demostración

Requisitos: Node.js 22 o superior y npm. Verificado con Node 24.14.1 y npm 11.11.0.

```bash
npm ci
cp .env.example .env.local
npm run dev -- --port 5173
```

Abre `http://localhost:5173/`. El ejemplo activa una **demostración con datos ficticios**, compartidos entre las vistas pública y del equipo en el mismo navegador. No utiliza contraseñas ni envía correos. Para probar:

1. Envía una solicitud con un correo ficticio, por ejemplo `cliente@example.com`.
2. Crea una cuenta ficticia con el mismo correo y consulta “Mi cuenta”.
3. Abre `/equipo.html`, busca la solicitud, agrega conceptos y márcala como “Cotización enviada”.
4. Regresa a “Mi cuenta” y actualiza; verás la propuesta y podrás generar su PDF.
5. Envía una segunda solicitud desde tu cuenta; tus datos de contacto ya están guardados.

La simulación de cuentas no es autenticación segura. No uses información real. Para reiniciarla, elimina únicamente las claves `climaxa-demo-v1` de localStorage, y `climaxa-customer-demo` / `climaxa-pending-claim` de sessionStorage.

## Crear el repositorio en línea

1. En tu cuenta de GitHub, crea un repositorio vacío llamado, por ejemplo, `climaxa-web`.
2. Sube **el contenido de este directorio a la raíz** del nuevo repositorio. También puedes usar el archivo ZIP entregado; excluye dependencias, contraseñas, configuración local y la carpeta Git.
3. No subas `.env.local`, `node_modules/` ni `dist/`.
4. Comparte el enlace del repositorio para continuar la configuración. La copia anterior en Mini súper permanece intacta; este es el proyecto independiente que contiene el portal del cliente.

## Supabase: base de datos y cuentas reales

1. Crea un proyecto en [Supabase](https://supabase.com/).
2. En SQL Editor de un proyecto nuevo ejecuta, en este orden:
   - `supabase/schema.sql`
   - `supabase/migrations/002_customer_portal.sql`
3. Si ya ejecutaste el esquema de la versión anterior, ejecuta **solo la migración 002**. Los scripts no son idempotentes; no los ejecutes dos veces.
4. En Authentication habilita correo/contraseña, registro de nuevos usuarios y **confirmación de correo**. El portal ahora necesita registro público: sustituye la instrucción de la versión anterior que pedía deshabilitarlo.
5. Configura SMTP para enviar confirmaciones y recuperación de contraseña a tus clientes. El servicio predeterminado de Supabase limita los destinatarios y el volumen; verifica el envío a una dirección real antes de publicar. Si habilitas CAPTCHA en Supabase Auth, debes integrar el widget y su token en el frontend antes de usar esta versión; aún no incluye ese widget.
6. En Authentication → Users crea una cuenta del equipo desde el administrador, con contraseña y correo confirmado. Activa el primer administrador en SQL Editor:

```sql
update public.profiles
set role='admin', active=true, name='Administrador CLIMAXA'
where email='TU_CORREO_DEL_EQUIPO';
```

Crea esta cuenta desde la consola, no desde el formulario público. Los registros del sitio obtienen únicamente el perfil `cliente`, con el consentimiento fechado en `customer_accounts`. Las cuentas del equipo creadas desde consola empiezan inactivas; el administrador puede activarlas y asignarles un perfil.

7. En `.env.local` o en las variables del alojamiento configura:

```dotenv
VITE_DEMO_MODE=false
VITE_SUPABASE_URL=https://TU_PROYECTO.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=TU_CLAVE_PUBLICABLE
```

Usa una clave **publishable** (o `anon` heredada), nunca una clave `service_role`, secret key o contraseña de base de datos. Las variables `VITE_` son públicas; RLS y las funciones SQL protegen los registros.

8. En Authentication → URL Configuration configura:
   - **Site URL:** la dirección HTTPS definitiva del sitio.
   - **Redirect URLs:** permite las rutas de ese dominio para confirmación y recuperación; por ejemplo `https://TU_SITIO.netlify.app/**`. Agrega localhost únicamente si vas a probar Auth desde desarrollo.

La cuenta nueva conserva el identificador de vinculación en sus metadatos de Auth hasta confirmar el correo; así puede terminar el registro desde otro dispositivo. Si la cuenta ya existía, la vinculación pendiente utiliza sessionStorage y debe completarse desde el navegador que envió la solicitud. Los identificadores vencen después de 30 días. No se vincula automáticamente un historial de solicitudes por coincidencia de correo.

## Publicar el sitio completo

En [Netlify](https://www.netlify.com/):

1. Conecta el **nuevo repositorio**, con los archivos de CLIMAXA en la raíz.
2. Base directory: raíz (vacío). Build command: `npm run build`. Publish directory: `dist`.
3. Configura las tres variables anteriores, con `VITE_DEMO_MODE=false`.
4. Publica y completa las URLs de Auth en Supabase.
5. Prueba solicitud de invitado → registro → correo de confirmación → cuenta → atención del equipo → propuesta visible al cliente. Prueba también recuperación de contraseña y una segunda cuenta sin acceso al historial de la primera.

`vite.config.js` genera ambas entradas HTML; `netlify.toml` configura compilación y cabeceras. Los cambios de variables requieren otra compilación. Puedes usar el subdominio del alojamiento o configurar el dominio de CLIMAXA cuando tengas acceso al DNS. La vista previa del entorno de desarrollo no es publicación permanente.

## Verificación y estructura

```bash
npm test
npm run build
npm audit
```

- `src/public.js` / `src/public.css`: página pública, formularios y “Mi cuenta”.
- `src/customer-data.js`: registro, acceso, recuperación, solicitudes y vinculación.
- `src/app.js` / `src/style.css`: panel del equipo.
- `src/data.js`, `src/domain.js`, `src/seed.js`: datos, cálculos y demostración.
- `supabase/schema.sql`: esquema original del equipo.
- `supabase/migrations/002_customer_portal.sql`: portal del cliente y permisos.
- `tests/`: validación de cálculos y PostgreSQL embebido (PGlite).

Las pruebas ejecutan las funciones y políticas SQL reales con identidades sintéticas. Comprueban consentimiento, aislamiento, correos verificados, tokens de vinculación, solicitudes idempotentes, límites por correo y permisos internos. No prueban el envío real de correos, Supabase alojado ni DNS.

## Operación

- El plan gratuito de Supabase tiene límites y puede pausar proyectos inactivos; no garantiza operación 24/7. Consulta [sus condiciones vigentes](https://supabase.com/pricing). El alojamiento también tiene límites.
- Las solicitudes públicas tienen un límite de cinco envíos por correo por hora. Este límite no reemplaza un servicio de protección contra abuso distribuido; verifica las protecciones del alojamiento al publicar un formulario público.
- Los precios son en MXN, con IVA configurable. Se generan propuestas imprimibles, no facturas.
- WhatsApp sigue siendo un canal manual. El sitio abre la conversación; no envía PDFs automáticamente.
- El texto “Uso de tus datos” explica este flujo. Antes de operar con clientes, CLIMAXA debe completar su aviso con los datos del responsable y su procedimiento de atención.
- El CSV no es un respaldo completo: utiliza las herramientas de respaldo de Supabase.
- Los datos del portal y del panel se actualizan al entrar o pulsar “Actualizar”; no se envían notificaciones automáticas.
