import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { PGlite } from "@electric-sql/pglite";
const migration = new URL(
  "../supabase/migrations/002_customer_portal.sql",
  import.meta.url,
);
test("public requests, explicit consent, verified claim, isolation, and staff regression", async () => {
  const db = new PGlite();
  const admin = "00000000-0000-0000-0000-000000000001",
    alice = "00000000-0000-0000-0000-000000000002",
    bob = "00000000-0000-0000-0000-000000000003";
  const key = "10000000-0000-0000-0000-000000000001",
    key2 = "10000000-0000-0000-0000-000000000002",
    token = "a".repeat(64);
  const payload = {
    name: "Alice",
    phone: "2280000000",
    email: "alice@example.com",
    title: "Mi proyecto",
    service: "Instalación",
    description: "Solicitud pública",
    contact_consent: true,
  };
  const as = async (id) => {
    await db.exec("reset role");
    await db.query("select set_config('request.jwt.claim.sub',$1,false)", [
      id || "",
    ]);
    await db.exec(`set role ${id ? "authenticated" : "anon"}`);
  };
  try {
    await db.exec(
      `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key,email text,raw_user_meta_data jsonb default '{}'::jsonb,email_confirmed_at timestamptz);create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;grant usage on schema public,auth to anon,authenticated;grant execute on function auth.uid() to anon,authenticated;`,
    );
    await db.exec(
      await readFile(
        new URL("../supabase/schema.sql", import.meta.url),
        "utf8",
      ),
    );
    // Migration also handles an already-existing staff account.
    await db.query("insert into auth.users(id,email) values($1,$2)", [
      admin,
      "admin@example.com",
    ]);
    await db.exec(await readFile(migration, "utf8"));
    await db.query("update profiles set role='admin',active=true where id=$1", [
      admin,
    ]);
    const signup = async (id, email, metadata) =>
      db.query(
        "insert into auth.users(id,email,raw_user_meta_data) values($1,$2,$3)",
        [id, email, metadata],
      );
    const meta = {
      signup_kind: "customer",
      name: "Alice",
      phone: "2280000000",
      account_consent: true,
      role: "admin",
      active: true,
    };
    await assert.rejects(
      signup(alice, "alice@example.com", { ...meta, account_consent: false }),
    );
    await signup(alice, "alice@example.com", meta);
    await signup(bob, "bob@example.com", { ...meta, name: "Bob" });
    assert.equal(
      (await db.query("select role from profiles where id=$1", [alice])).rows[0]
        .role,
      "cliente",
    );
    assert.equal(
      (await db.query("select count(*)::int n from customer_accounts")).rows[0]
        .n,
      2,
    );
    const bobClient = (
      await db.query(
        "select client_id from customer_accounts where user_id=$1",
        [bob],
      )
    ).rows[0].client_id;
    await as(null);
    await assert.rejects(db.query("select * from clients"));
    await assert.rejects(db.query("select * from request_receipts"));
    await assert.rejects(
      db.query("select submit_guest_request($1,$2,$3)", [
        { ...payload, contact_consent: false },
        key,
        token,
      ]),
    );
    await assert.rejects(
      db.query("select submit_guest_request($1,$2,$3)", [
        { ...payload, email: "no-email" },
        key,
        token,
      ]),
    );
    const result = (
      await db.query("select submit_guest_request($1,$2,$3) value", [
        { ...payload, status: "Aceptada", tax: 0, items: [{ price: 1 }] },
        key,
        token,
      ])
    ).rows[0].value;
    const retry = (
      await db.query("select submit_guest_request($1,$2,$3) value", [
        payload,
        key,
        token,
      ])
    ).rows[0].value;
    assert.equal(result.number, retry.number);
    await assert.rejects(
      db.query("select submit_guest_request($1,$2,$3)", [
        payload,
        key,
        "b".repeat(64),
      ]),
    );
    await as(admin);
    let q = (
      await db.query("select * from quotes where number=$1", [result.number])
    ).rows[0];
    assert.equal(q.status, "Nueva solicitud");
    assert.deepEqual(q.items, []);
    await db.query("select add_note($1,$2)", [
      q.id,
      "Nota interna no compartida",
    ]);
    await db.query(
      'update quotes set items=\'[{"description":"Borrador secreto","quantity":1,"price":1200}]\' where id=$1',
      [q.id],
    );
    await as(alice);
    await assert.rejects(
      db.query("select claim_guest_request($1,$2)", [key, token]),
    ); // Unconfirmed email.
    await db.exec("reset role");
    await db.query(
      "update auth.users set email_confirmed_at=now() where id in ($1,$2)",
      [alice, bob],
    );
    await as(bob);
    await assert.rejects(
      db.query("select claim_guest_request($1,$2)", [key, token]),
    ); // Correct token, wrong verified email.
    await as(alice);
    await assert.rejects(
      db.query("select claim_guest_request($1,$2)", [key, "b".repeat(64)]),
    );
    // A receipt must not reclaim a request the staff reassigned to someone else.
    await as(admin);
    await db.query("update quotes set client_id=$1 where id=$2", [
      bobClient,
      q.id,
    ]);
    await as(alice);
    await assert.rejects(
      db.query("select claim_guest_request($1,$2)", [key, token]),
    );
    await as(admin);
    await db.query("update quotes set client_id=$1 where id=$2", [
      q.client_id,
      q.id,
    ]);
    await as(alice);
    await db.query("select claim_guest_request($1,$2)", [key, token]);
    await db.query("select claim_guest_request($1,$2)", [key, token]); // Idempotent.
    for (const table of ["clients", "quotes", "events"])
      assert.equal((await db.query(`select * from ${table}`)).rows.length, 0);
    await assert.rejects(db.query("select * from customer_accounts"));
    assert.equal((await db.query("select * from profiles")).rows.length, 1);
    const own = (await db.query("select my_customer_quotes() value")).rows[0]
      .value;
    assert.equal(own.length, 1);
    assert.deepEqual(own[0].items, []);
    assert.equal(own[0].tax, null);
    assert.equal(own[0].description, undefined);
    assert.equal(own[0].follow_up, undefined);
    assert.equal(
      (await db.query("select my_customer_account() value")).rows[0].value
        .email,
      "alice@example.com",
    );
    await assert.rejects(
      db.query(
        "insert into quotes(client_id,title,service) values($1,'hack','Instalación')",
        [q.client_id],
      ),
    );
    await assert.rejects(db.query("select add_note($1,$2)", [q.id, "hack"]));
    await assert.rejects(
      db.query("select set_user_access($1,$2,$3)", [bob, "admin", true]),
    );
    const signed = (
      await db.query("select submit_customer_request($1,$2) value", [
        { ...payload, client_id: q.client_id, status: "Aceptada" },
        key2,
      ])
    ).rows[0].value;
    assert.equal(
      (
        await db.query("select submit_customer_request($1,$2) value", [
          payload,
          key2,
        ])
      ).rows[0].value.number,
      signed.number,
    );
    await as(bob);
    assert.deepEqual(
      (await db.query("select my_customer_quotes() value")).rows[0].value,
      [],
    );
    await assert.rejects(
      db.query("select submit_customer_request($1,$2)", [payload, key2]),
    );
    await as(admin);
    assert.equal((await db.query("select * from quotes")).rows.length, 2);
    await db.query(
      "update quotes set status='Cotización enviada' where id=$1",
      [q.id],
    );
    await assert.rejects(
      db.query("select set_user_access($1,$2,$3)", [alice, "admin", true]),
    );
    await as(alice);
    const published = (
      await db.query("select my_customer_quotes() value")
    ).rows[0].value.find((v) => v.id === q.id);
    assert.equal(published.items[0].price, 1200);
    assert.equal(published.status, "Cotización enviada");
    await as(admin);
    await db.query("select set_user_access($1,$2,$3)", [
      alice,
      "cliente",
      false,
    ]);
    await as(alice);
    await assert.rejects(db.query("select my_customer_quotes()"));
    await assert.rejects(db.query("select my_customer_account()"));
    await assert.rejects(
      db.query("select submit_customer_request($1,$2)", [payload, key2]),
    );
    // Server-side limit: changing submission UUID does not bypass the per-email hourly cap.
    await as(null);
    for (let i = 3; i <= 5; i++)
      await db.query("select submit_guest_request($1,$2,$3)", [
        payload,
        `10000000-0000-0000-0000-00000000000${i}`,
        token,
      ]);
    await assert.rejects(
      db.query("select submit_guest_request($1,$2,$3)", [
        payload,
        "10000000-0000-0000-0000-000000000006",
        token,
      ]),
    );
  } finally {
    await db.close();
  }
});
