import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { PGlite } from "@electric-sql/pglite";
test("database access, validation, versioning and immutable history", async () => {
  const db = new PGlite();
  const ids = {
    admin: "00000000-0000-0000-0000-000000000001",
    sales: "00000000-0000-0000-0000-000000000002",
    reader: "00000000-0000-0000-0000-000000000003",
    inactive: "00000000-0000-0000-0000-000000000004",
  };
  try {
    await db.exec(
      `create role anon; create role authenticated; create schema auth; create table auth.users(id uuid primary key,email text,raw_user_meta_data jsonb default '{}'::jsonb); create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$; grant usage on schema public,auth to authenticated; grant execute on function auth.uid() to authenticated;`,
    );
    await db.exec(
      await readFile(
        new URL("../supabase/schema.sql", import.meta.url),
        "utf8",
      ),
    );
    for (const [name, id] of Object.entries(ids))
      await db.query("insert into auth.users(id,email) values($1,$2)", [
        id,
        `${name}@example.com`,
      ]);
    assert.equal(
      (
        await db.query(
          "select count(*)::int n from profiles where active=false",
        )
      ).rows[0].n,
      4,
    );
    await db.exec(
      `update profiles set active=true,role=case when name='admin' then 'admin' when name='sales' then 'comercial' else 'consulta' end where name<>'inactive'`,
    );
    const as = async (name) => {
      await db.exec("reset role");
      await db.query("select set_config('request.jwt.claim.sub',$1,false)", [
        ids[name] || "",
      ]);
      await db.exec(`set role ${name === "anon" ? "anon" : "authenticated"}`);
    };
    await as("sales");
    const c = (
      await db.query(
        "insert into clients(name,phone) values('Cliente','2280000000') returning id",
      )
    ).rows[0].id;
    const q = (
      await db.query(
        "insert into quotes(client_id,title,service) values($1,'Proyecto','Instalación') returning id,version",
        [c],
      )
    ).rows[0];
    assert.equal(q.version, 1);
    const initial = (
      await db.query("select * from events where quote_id=$1", [q.id])
    ).rows[0];
    assert.equal(initial.actor_name, "sales");
    assert.equal(initial.snapshot.client_snapshot.name, "Cliente");
    await assert.rejects(
      db.query("update quotes set status='Cotización enviada' where id=$1", [
        q.id,
      ]),
    );
    await assert.rejects(
      db.query(
        'update quotes set items=\'[{"description":"x","quantity":-1,"price":100}]\' where id=$1',
        [q.id],
      ),
    );
    await assert.rejects(
      db.query(
        'update quotes set items=\'[{"description":"x","quantity":1}]\' where id=$1',
        [q.id],
      ),
    );
    await assert.rejects(
      db.query("update quotes set version=90 where id=$1", [q.id]),
    );
    await db.query(
      'update quotes set items=\'[{"description":"x","quantity":1,"price":100}]\',status=\'Cotización enviada\' where id=$1 and version=1',
      [q.id],
    );
    assert.equal(
      (await db.query("select version from quotes where id=$1", [q.id])).rows[0]
        .version,
      2,
    );
    assert.equal(
      (
        await db.query(
          "update quotes set title='Stale edit' where id=$1 and version=1 returning id",
          [q.id],
        )
      ).rows.length,
      0,
    );
    await db.query("update clients set name='Nuevo nombre' where id=$1", [c]);
    assert.equal(
      (await db.query("select snapshot from events where id=$1", [initial.id]))
        .rows[0].snapshot.client_snapshot.name,
      "Cliente",
    );
    await db.query("select add_note($1,$2)", [q.id, "Llamada de seguimiento"]);
    await assert.rejects(
      db.query(
        "insert into events(quote_id,kind,message,actor_name) values($1,'note','Falso','Admin')",
        [q.id],
      ),
    );
    await assert.rejects(db.query("delete from quotes where id=$1", [q.id]));
    await assert.rejects(
      db.query("update profiles set role=$1 where id=$2", ["admin", ids.sales]),
    );
    await assert.rejects(
      db.query("select set_user_access($1,$2,$3)", [ids.reader, "admin", true]),
    );
    await as("reader");
    assert.equal((await db.query("select * from quotes")).rows.length, 1);
    assert.equal(
      (await db.query("update quotes set title='No autorizado' returning id"))
        .rows.length,
      0,
    );
    await assert.rejects(
      db.query("select add_note($1,$2)", [q.id, "No autorizado"]),
    );
    await assert.rejects(
      db.query("insert into clients(name,phone) values('No','2280000000')"),
    );
    await as("inactive");
    assert.equal((await db.query("select * from quotes")).rows.length, 0);
    assert.equal((await db.query("select * from clients")).rows.length, 0);
    assert.equal((await db.query("select * from events")).rows.length, 0);
    await as("anon");
    await assert.rejects(db.query("select * from quotes"));
    await as("admin");
    assert.equal((await db.query("select * from profiles")).rows.length, 4);
    await db.query("select set_user_access($1,$2,$3)", [
      ids.reader,
      "comercial",
      true,
    ]);
    await assert.rejects(
      db.query("select set_user_access($1,$2,$3)", [
        ids.admin,
        "consulta",
        false,
      ]),
    );
    await db.query("select set_user_access($1,$2,$3)", [
      ids.sales,
      "comercial",
      false,
    ]);
    await as("sales");
    assert.equal((await db.query("select * from quotes")).rows.length, 0);
  } finally {
    await db.close();
  }
});
