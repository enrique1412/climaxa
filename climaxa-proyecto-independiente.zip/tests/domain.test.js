import test from "node:test";
import assert from "node:assert/strict";
import {
  totals,
  validateQuote,
  csvCell,
  escapeHtml,
  pending,
} from "../src/domain.js";
const quote = {
  client_id: "client",
  title: "Proyecto",
  service: "Instalación",
  status: "Nueva solicitud",
  tax: 16,
  items: [],
};
test("round line amounts and tax to cents", () => {
  assert.deepEqual(
    totals(
      [
        { quantity: 3, price: 0.1 },
        { quantity: 2, price: 12.35 },
      ],
      16,
    ),
    { subtotal: 25, tax: 4, total: 29 },
  );
  assert.deepEqual(totals([], 0), { subtotal: 0, tax: 0, total: 0 });
});
test("requests can start unpriced; sent proposals must have items", () => {
  assert.equal(validateQuote(quote), quote);
  assert.throws(() =>
    validateQuote({ ...quote, status: "Cotización enviada" }),
  );
  assert.doesNotThrow(() =>
    validateQuote({
      ...quote,
      status: "Aceptada",
      items: [{ description: "Servicio", quantity: 1, price: 100 }],
    }),
  );
});
test("invalid money and quantities are rejected", () => {
  for (const item of [
    { description: "x", quantity: 0, price: 10 },
    { description: "x", quantity: 1, price: -2 },
    { description: "", quantity: 1, price: 10 },
    { description: "x", quantity: 1, price: Infinity },
  ])
    assert.throws(() => validateQuote({ ...quote, items: [item] }));
  for (const tax of [-1, 101, NaN])
    assert.throws(() => validateQuote({ ...quote, tax }));
});
test("HTML and CSV exports escape untrusted content", () => {
  assert.equal(escapeHtml('<script>"&'), "&lt;script&gt;&quot;&amp;");
  assert.equal(csvCell("=1+1"), '"\'=1+1"');
  assert.equal(csvCell(" \t@SUM(A1)"), '"\' \t@SUM(A1)"');
  assert.equal(csvCell('a,"b"'), '"a,""b"""');
});
test("accepted, rejected and finished requests leave pending list", () => {
  assert.deepEqual(
    pending(
      [
        "Nueva solicitud",
        "Cotización enviada",
        "Aceptada",
        "Rechazada",
        "Finalizada",
      ].map((status) => ({ status })),
    ).map((q) => q.status),
    ["Nueva solicitud", "Cotización enviada"],
  );
});
